import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { useData } from '../contexts/DataContext.tsx';
import { AdminDashboardView } from '../components/dashboard/AdminDashboardView.tsx';
import { ManagerDashboardView } from '../components/dashboard/ManagerDashboardView.tsx';
import { TechnicianDashboardView } from '../components/dashboard/TechnicianDashboardView.tsx';
import { ProductionPlannerDashboardView } from '../components/dashboard/ProductionPlannerDashboardView.tsx';
import { SuperAdminReservedView } from '../components/dashboard/SuperAdminReservedView.tsx';
import { MachineDetailModal } from '../components/MachineDetailModal.tsx';
import { CreateIncidentModal } from '../components/CreateIncidentModal.tsx';
import { CreateWorkOrderModal } from '../components/CreateWorkOrderModal.tsx';
import type { Machine } from '../types/index.ts';
import { RefreshCw, Factory as FactoryIcon, Building2 } from 'lucide-react';

export const DashboardPage: React.FC = () => {
  const { user, activeFactory } = useAuth();
  const {
    machines,
    production,
    incidents,
    workOrders,
    maintenance,
    sops,
    kpis,
    isLoading,
    refreshData,
    createIncident,
    createWorkOrder
  } = useData();

  const [selectedMachine, setSelectedMachine] = useState<Machine | null>(null);
  const [isIncidentModalOpen, setIsIncidentModalOpen] = useState(false);
  const [isWorkOrderModalOpen, setIsWorkOrderModalOpen] = useState(false);

  if (isLoading && machines.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-3">
        <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin" />
        <p className="text-sm font-medium text-slate-600">Loading Operations Intelligence...</p>
      </div>
    );
  }

  const renderRoleDashboard = () => {
    switch (user?.role) {
      case 'SUPER_ADMIN':
        return <SuperAdminReservedView />;

      case 'TECHNICIAN':
      case 'OPERATOR':
        return (
          <TechnicianDashboardView
            machines={machines}
            workOrders={workOrders}
            maintenance={maintenance}
            incidents={incidents}
            sops={sops}
            onSelectMachine={(m) => setSelectedMachine(m)}
            onOpenWorkOrderModal={() => setIsWorkOrderModalOpen(true)}
          />
        );

      case 'PRODUCTION_PLANNER':
      case 'ANALYST':
        return (
          <ProductionPlannerDashboardView
            machines={machines}
            production={production}
            workOrders={workOrders}
            maintenance={maintenance}
            kpis={kpis}
            onSelectMachine={(m) => setSelectedMachine(m)}
            onOpenWorkOrderModal={() => setIsWorkOrderModalOpen(true)}
          />
        );

      case 'MANAGER_SUPERVISOR':
      case 'FACTORY_MANAGER':
      case 'SUPERVISOR':
        return (
          <ManagerDashboardView
            machines={machines}
            production={production}
            incidents={incidents}
            workOrders={workOrders}
            maintenance={maintenance}
            kpis={kpis}
            onSelectMachine={(m) => setSelectedMachine(m)}
            onOpenIncidentModal={() => setIsIncidentModalOpen(true)}
            onOpenWorkOrderModal={() => setIsWorkOrderModalOpen(true)}
          />
        );

      case 'ADMIN':
      case 'FACTORY_OWNER':
      default:
        return (
          <AdminDashboardView
            machines={machines}
            production={production}
            incidents={incidents}
            workOrders={workOrders}
            maintenance={maintenance}
            kpis={kpis}
            onSelectMachine={(m) => setSelectedMachine(m)}
            onOpenIncidentModal={() => setIsIncidentModalOpen(true)}
            onOpenWorkOrderModal={() => setIsWorkOrderModalOpen(true)}
          />
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {renderRoleDashboard()}

      {/* Machine Detail Modal */}
      {selectedMachine && (
        <MachineDetailModal
          machine={selectedMachine}
          onClose={() => setSelectedMachine(null)}
          incidents={incidents}
          workOrders={workOrders}
          production={production}
        />
      )}

      {/* Create Incident Modal */}
      <CreateIncidentModal
        isOpen={isIncidentModalOpen}
        machines={machines}
        onClose={() => setIsIncidentModalOpen(false)}
        onSubmit={async (data) => {
          await createIncident(data);
          setIsIncidentModalOpen(false);
        }}
      />

      {/* Create Work Order Modal */}
      <CreateWorkOrderModal
        isOpen={isWorkOrderModalOpen}
        machines={machines}
        onClose={() => setIsWorkOrderModalOpen(false)}
        onSubmit={async (data) => {
          await createWorkOrder(data);
          setIsWorkOrderModalOpen(false);
        }}
      />
    </div>
  );
};
