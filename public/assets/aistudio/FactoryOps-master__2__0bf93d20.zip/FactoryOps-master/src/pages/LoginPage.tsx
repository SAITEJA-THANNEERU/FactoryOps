import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { useRouter } from '../contexts/RouterContext.tsx';
import {
  Factory,
  Lock,
  Mail,
  Eye,
  EyeOff,
  ShieldCheck,
  Building2,
  ArrowRight,
  AlertCircle,
  KeyRound
} from 'lucide-react';

export const LoginPage: React.FC = () => {
  const { login, isLoading, error: authError } = useAuth();
  const { navigate } = useRouter();

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError(null);

    if (!identifier.trim() || !password) {
      setLocalError('Please enter both your email/username and password');
      return;
    }

    try {
      await login({ email: identifier, password });
      // Router will automatically shift based on user role in AppContent
    } catch (err: any) {
      setLocalError(err.message || 'Invalid credentials. Please verify your credentials.');
    }
  };

  const setCredentialsPreset = (emailVal: string, passVal: string) => {
    setIdentifier(emailVal);
    setPassword(passVal);
    setLocalError(null);
  };

  const displayError = localError || authError;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8 relative">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        {/* Brand Header */}
        <div className="flex justify-center mb-3">
          <div className="w-12 h-12 rounded-xl bg-slate-900 flex items-center justify-center text-white shadow-md">
            <Factory className="w-6 h-6 text-emerald-400" />
          </div>
        </div>
        <h2 className="text-center text-2xl font-bold tracking-tight text-slate-900">
          FactoryOps
        </h2>
        <p className="mt-1 text-center text-xs text-slate-500 font-medium">
          Smart Factory Operations & Maintenance Platform
        </p>
      </div>

      <div className="mt-6 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white border border-slate-200 py-8 px-6 shadow-sm rounded-xl sm:px-10">
          {displayError && (
            <div className="mb-5 p-3 rounded-md bg-rose-50 border border-rose-200 flex items-center gap-2 text-xs text-rose-700">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{displayError}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Username or Work Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  autoComplete="username"
                  value={identifier}
                  onChange={e => setIdentifier(e.target.value)}
                  placeholder="e.g. superadmin@factoryops.com"
                  className="w-full bg-slate-50 border border-slate-200 rounded-md pl-9 pr-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-emerald-600 focus:bg-white transition-colors"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full bg-slate-50 border border-slate-200 rounded-md pl-9 pr-10 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-hidden focus:border-emerald-600 focus:bg-white transition-colors"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-2 py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm rounded-md shadow-xs flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Signing In...</span>
                </>
              ) : (
                <>
                  <span>Sign In to Plant Console</span>
                  <ArrowRight className="w-4 h-4 text-emerald-400" />
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Credentials Preset Bar */}
          <div className="mt-7 pt-5 border-t border-slate-100">
            <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2.5">
              <KeyRound className="w-3.5 h-3.5 text-emerald-600" />
              <span>One-Click Demo Credentials</span>
            </div>

            <div className="grid grid-cols-1 gap-1.5 text-xs">
              <button
                type="button"
                onClick={() => setCredentialsPreset('admin.apex@factoryops.com', 'Admin@123')}
                className="w-full text-left px-2.5 py-1.5 rounded-md bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-colors flex items-center justify-between"
              >
                <div>
                  <span className="font-semibold text-emerald-800">Admin</span>
                  <span className="text-[11px] text-slate-500 ml-1.5">(Plant Overview • FAC-001)</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500">admin.apex@factoryops.com</span>
              </button>

              <button
                type="button"
                onClick={() => setCredentialsPreset('manager.apex@factoryops.com', 'Manager@123')}
                className="w-full text-left px-2.5 py-1.5 rounded-md bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-colors flex items-center justify-between"
              >
                <div>
                  <span className="font-semibold text-blue-700">Manager / Supervisor</span>
                  <span className="text-[11px] text-slate-500 ml-1.5">(Floor Operations)</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500">manager.apex@factoryops.com</span>
              </button>

              <button
                type="button"
                onClick={() => setCredentialsPreset('tech.apex@factoryops.com', 'Tech@123')}
                className="w-full text-left px-2.5 py-1.5 rounded-md bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-colors flex items-center justify-between"
              >
                <div>
                  <span className="font-semibold text-amber-700">Technician</span>
                  <span className="text-[11px] text-slate-500 ml-1.5">(Work Orders & Repairs)</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500">tech.apex@factoryops.com</span>
              </button>

              <button
                type="button"
                onClick={() => setCredentialsPreset('planner.apex@factoryops.com', 'Planner@123')}
                className="w-full text-left px-2.5 py-1.5 rounded-md bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-colors flex items-center justify-between"
              >
                <div>
                  <span className="font-semibold text-indigo-700">Production Planner</span>
                  <span className="text-[11px] text-slate-500 ml-1.5">(Targets & Shortfall)</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500">planner.apex@factoryops.com</span>
              </button>

              <button
                type="button"
                onClick={() => setCredentialsPreset('superadmin@factoryops.com', 'SuperAdmin@123')}
                className="w-full text-left px-2.5 py-1.5 rounded-md bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-colors flex items-center justify-between"
              >
                <div>
                  <span className="font-semibold text-purple-700">Super Admin</span>
                  <span className="text-[11px] text-slate-500 ml-1.5">(Reserved Dashboard)</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500">superadmin@factoryops.com</span>
              </button>
            </div>
          </div>
        </div>

        <div className="mt-5 flex items-center justify-center gap-1.5 text-xs text-slate-500">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>PBKDF2 Password Hashing • Isolated Tenant Namespaces</span>
        </div>
      </div>
    </div>
  );
};
