import React, { useState } from 'react';
import { useData } from '../contexts/DataContext.tsx';
import { useFilters } from '../contexts/FilterContext.tsx';
import { StatusBadge } from '../components/StatusBadge.tsx';
import { GlobalFilterBar } from '../components/GlobalFilterBar.tsx';
import { MachineDetailModal } from '../components/MachineDetailModal.tsx';
import type { Machine } from '../types/index.ts';
import { Cpu, ArrowUpRight, Gauge, Thermometer, Zap } from 'lucide-react';

export const MachinesPage: React.FC = () => {
  const { machines, incidents, workOrders, production } = useData();
  const { selectedLine, selectedStatus, searchQuery } = useFilters();
  const [selectedMachine, setSelectedMachine] = useState<Machine | null>(null);

  const filteredMachines = machines.filter(m => {
    if (selectedLine !== 'all' && m.line !== selectedLine) return false;
    if (selectedStatus !== 'all' && m.status !== selectedStatus) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        m.machine_id.toLowerCase().includes(q) ||
        m.name.toLowerCase().includes(q) ||
        m.operator.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Cpu className="w-5 h-5 text-emerald-600" />
            <span>Plant Equipment Fleet & Telemetry</span>
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Operational status, health scores, vibration telemetry, and machine service history
          </p>
        </div>
        <div className="text-xs text-slate-500 font-medium">
          Showing <span className="font-bold text-slate-900">{filteredMachines.length}</span> of {machines.length} units
        </div>
      </div>

      <GlobalFilterBar />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredMachines.map(m => (
          <div
            key={m.id}
            onClick={() => setSelectedMachine(m)}
            className="bg-white hover:bg-slate-50/80 border border-slate-200 rounded-lg p-5 cursor-pointer transition-colors shadow-xs group"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="font-mono text-xs font-bold text-emerald-800">
                {m.machine_id}
              </span>
              <StatusBadge status={m.status} size="sm" />
            </div>

            <h3 className="text-sm font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
              {m.name}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">{m.line}</p>

            <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-3 gap-2 text-xs">
              <div className="bg-slate-50 p-2 rounded-md">
                <span className="text-[10px] text-slate-400 block font-medium">Health</span>
                <span className="font-bold text-slate-900">{m.health_score}%</span>
              </div>
              <div className="bg-slate-50 p-2 rounded-md">
                <span className="text-[10px] text-slate-400 block font-medium">Temp</span>
                <span className="font-medium text-slate-900">{m.temperature_c}°C</span>
              </div>
              <div className="bg-slate-50 p-2 rounded-md">
                <span className="text-[10px] text-slate-400 block font-medium">OEE</span>
                <span className="font-bold text-emerald-800">{m.oee}%</span>
              </div>
            </div>

            <div className="mt-3 flex items-center justify-between text-[11px] text-slate-500">
              <span>Op: {m.operator}</span>
              <span className="text-emerald-700 font-medium flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                View Telemetry <ArrowUpRight className="w-3 h-3" />
              </span>
            </div>
          </div>
        ))}
      </div>

      <MachineDetailModal
        machine={selectedMachine}
        onClose={() => setSelectedMachine(null)}
        incidents={incidents}
        workOrders={workOrders}
        production={production}
      />
    </div>
  );
};
