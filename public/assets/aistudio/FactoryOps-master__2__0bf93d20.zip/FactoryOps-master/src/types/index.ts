export type UserRole =
  | 'SUPER_ADMIN'
  | 'ADMIN'
  | 'MANAGER_SUPERVISOR'
  | 'TECHNICIAN'
  | 'PRODUCTION_PLANNER'
  | 'FACTORY_OWNER'
  | 'FACTORY_MANAGER'
  | 'SUPERVISOR'
  | 'OPERATOR'
  | 'ANALYST';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  factory_id: string | null;
  factory_name?: string;
  status: 'active' | 'inactive';
  created_at: string;
}

export interface Factory {
  id: string;
  factory_code: string;
  name: string;
  location: string;
  industry: string;
  owner_name: string;
  status: 'Operational' | 'Maintenance Alert' | 'Production Slowdown';
  capacity: string;
  established_year: number;
  created_at: string;
  machine_count?: number;
  running_count?: number;
  oee?: number;
  active_incidents?: number;
  open_work_orders?: number;
  last_activity?: string;
}

export type MachineStatus = 'running' | 'warning' | 'maintenance' | 'offline';

export interface Machine {
  id: string;
  factory_id: string;
  machine_id: string;
  name: string;
  type: string;
  line: string;
  status: MachineStatus;
  health_score: number;
  temperature_c: number;
  vibration_mms: number;
  pressure_bar: number;
  speed_rpm: number;
  oee: number;
  operator: string;
  install_date: string;
  last_service_date: string;
}

export interface ProductionRecord {
  id: string;
  factory_id: string;
  machine_id: string;
  timestamp: string;
  shift: 'Morning' | 'Afternoon' | 'Night';
  target_units: number;
  actual_units: number;
  defective_units: number;
  scrap_kg: number;
  cycle_time_sec: number;
  operator: string;
}

export type MaintenanceType = 'Preventive' | 'Corrective' | 'Predictive' | 'Emergency';
export type MaintenanceStatus = 'Scheduled' | 'In Progress' | 'Completed' | 'Pending Approval';

export interface MaintenanceRecord {
  id: string;
  factory_id: string;
  machine_id: string;
  type: MaintenanceType;
  status: MaintenanceStatus;
  scheduled_date: string;
  completed_date?: string;
  technician: string;
  description: string;
  cost_usd: number;
  downtime_hours: number;
}

export type IncidentSeverity = 'Critical' | 'High' | 'Medium' | 'Low';
export type IncidentStatus = 'Open' | 'Investigating' | 'Resolved' | 'Closed';

export interface Incident {
  id: string;
  incident_id: string;
  factory_id: string;
  machine_id: string;
  title: string;
  description: string;
  severity: IncidentSeverity;
  status: IncidentStatus;
  reported_by: string;
  reported_at: string;
  resolved_at?: string;
  root_cause?: string;
  resolution_notes?: string;
}

export type WorkOrderPriority = 'Critical' | 'High' | 'Medium' | 'Low';
export type WorkOrderStatus = 'Pending' | 'In Progress' | 'Completed' | 'Cancelled';

export interface WorkOrder {
  id: string;
  work_order_id: string;
  factory_id: string;
  machine_id: string;
  title: string;
  priority: WorkOrderPriority;
  status: WorkOrderStatus;
  assigned_to: string;
  due_date: string;
  created_at: string;
  completed_at?: string;
  estimated_hours: number;
  actual_hours?: number;
  parts_required?: string;
}

export interface SOP {
  id: string;
  sop_id: string;
  factory_id: string;
  title: string;
  machine_type: string;
  category: 'Operating Procedure' | 'Safety Protocol' | 'Maintenance Guide' | 'Quality Inspection';
  version: string;
  last_updated: string;
  author: string;
  steps: string[];
  safety_precautions: string[];
  target_audience: string;
}

export interface DataQualityMetric {
  id: string;
  factory_id: string;
  sensor_name: string;
  machine_id: string;
  uptime_percentage: number;
  data_completeness_pct: number;
  latency_ms: number;
  anomalies_detected: number;
  status: 'Healthy' | 'Degraded' | 'Critical';
  last_sync: string;
}

export interface FactoryKPIs {
  factory_id: string;
  factory_name: string;
  total_machines: number;
  running_machines: number;
  warning_machines: number;
  maintenance_machines: number;
  offline_machines: number;
  oee: number;
  availability: number;
  performance: number;
  quality: number;
  total_production_units: number;
  target_production_units: number;
  defective_units: number;
  defect_rate_pct: number;
  downtime_hours: number;
  active_incidents: number;
  critical_incidents: number;
  open_work_orders: number;
  pending_maintenance: number;
  avg_health_score: number;
}

export interface SuperAdminOverview {
  total_factories: number;
  active_factories: number;
  total_users: number;
  total_machines: number;
  total_production: number;
  active_incidents: number;
  open_work_orders: number;
  overall_oee: number;
  overall_health: number;
  factories: (Factory & {
    kpis: FactoryKPIs;
  })[];
}

export interface AuthSession {
  token: string;
  user: User;
  factory?: Factory | null;
}
