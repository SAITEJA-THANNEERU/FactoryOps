import React from 'react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { useRouter } from '../contexts/RouterContext.tsx';
import {
  Factory as FactoryIcon,
  LogOut,
  ArrowLeft,
  Building2,
  Clock,
  UserCheck,
  AlertCircle
} from 'lucide-react';

export const Header: React.FC = () => {
  const { user, activeFactory, inspectingFactory, stopInspectingFactory, logout, switchDemoRole } = useAuth();
  const { navigate } = useRouter();

  const handleBackToSuperAdmin = () => {
    stopInspectingFactory();
    navigate('/super-admin/overview');
  };

  const getRoleBadgeStyle = (role?: string) => {
    switch (role) {
      case 'SUPER_ADMIN':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'ADMIN':
      case 'FACTORY_OWNER':
        return 'bg-emerald-50 text-emerald-800 border-emerald-200';
      case 'MANAGER_SUPERVISOR':
      case 'FACTORY_MANAGER':
      case 'SUPERVISOR':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'TECHNICIAN':
      case 'OPERATOR':
        return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'PRODUCTION_PLANNER':
      case 'ANALYST':
        return 'bg-indigo-50 text-indigo-700 border-indigo-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  const getRoleDisplayName = (role?: string) => {
    switch (role) {
      case 'SUPER_ADMIN':
        return 'Super Admin';
      case 'ADMIN':
      case 'FACTORY_OWNER':
        return 'Admin';
      case 'MANAGER_SUPERVISOR':
      case 'FACTORY_MANAGER':
      case 'SUPERVISOR':
        return 'Manager / Supervisor';
      case 'TECHNICIAN':
      case 'OPERATOR':
        return 'Technician';
      case 'PRODUCTION_PLANNER':
      case 'ANALYST':
        return 'Production Planner';
      default:
        return role || 'User';
    }
  };

  return (
    <header className="bg-white border-b border-slate-200 text-slate-900 sticky top-0 z-40 shadow-xs">
      {/* Super Admin Inspection Banner if inspecting a specific factory */}
      {inspectingFactory && (
        <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 flex items-center justify-between text-xs text-amber-900">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
            </span>
            <span className="font-bold uppercase tracking-wider text-amber-800">Inspecting Tenant:</span>
            <span className="font-bold text-slate-900">{inspectingFactory.name}</span>
            <span className="hidden sm:inline text-amber-800">
              ({inspectingFactory.location} • {inspectingFactory.industry})
            </span>
          </div>
          <button
            onClick={handleBackToSuperAdmin}
            className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-900 hover:bg-slate-800 text-white font-medium rounded text-xs transition-colors shadow-2xs"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to All Factories</span>
          </button>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Left: Branding & Active Factory */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-slate-900 flex items-center justify-center text-white shadow-xs">
              <FactoryIcon className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-base font-bold tracking-tight text-slate-900">FactoryOps</span>
                <span className="text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-300 px-1.5 py-0.2 rounded uppercase tracking-wider">
                  Industrial 4.0
                </span>
              </div>
              <p className="text-[10px] text-slate-500 font-medium hidden sm:block">Operations & Maintenance Platform</p>
            </div>
          </div>

          {/* Plant Context Indicator */}
          {activeFactory && (
            <div className="hidden md:flex items-center gap-2 pl-4 border-l border-slate-200">
              <div className="p-1 rounded bg-slate-100 border border-slate-200 text-slate-600">
                <Building2 className="w-3.5 h-3.5 text-emerald-600" />
              </div>
              <div className="text-left">
                <div className="text-xs font-bold text-slate-900 truncate max-w-[220px]">
                  {activeFactory.name}
                </div>
                <div className="flex items-center gap-1 text-[10px] text-slate-500">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  <span>{activeFactory.location}</span>
                  <span className="text-slate-300">•</span>
                  <span className="font-mono text-slate-500">{activeFactory.factory_code}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right: Role Switcher, Shift Status, User Role, Logout */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Demo Role Switcher */}
          <div className="flex items-center gap-1.5 px-2 py-1 bg-slate-100/80 hover:bg-slate-100 border border-slate-200 rounded-md text-xs">
            <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider hidden sm:inline">Role:</span>
            <select
              value={user?.role || ''}
              onChange={(e) => {
                const targetRole = e.target.value as any;
                if (targetRole) {
                  switchDemoRole(targetRole);
                }
              }}
              className="bg-transparent text-xs font-semibold text-slate-800 focus:outline-hidden cursor-pointer"
              title="Fast Switch Role for Testing"
            >
              <option value="ADMIN">Admin</option>
              <option value="MANAGER_SUPERVISOR">Manager / Supervisor</option>
              <option value="TECHNICIAN">Technician</option>
              <option value="PRODUCTION_PLANNER">Production Planner</option>
              <option value="SUPER_ADMIN">Super Admin (Reserved)</option>
            </select>
          </div>

          <div className="hidden xl:flex items-center gap-2 px-2.5 py-1 rounded bg-slate-50 border border-slate-200 text-xs text-slate-600">
            <Clock className="w-3.5 h-3.5 text-emerald-600" />
            <span>Shift 1 (Day)</span>
            <span className="text-slate-300">|</span>
            <span className="text-emerald-700 font-medium">Synced</span>
          </div>

          {/* User Profile Pill */}
          <div className="flex items-center gap-2.5 pl-2 sm:pl-3 border-l border-slate-200">
            <div className="text-right hidden sm:block">
              <div className="text-xs font-bold text-slate-900 flex items-center justify-end gap-1">
                <span>{user?.name}</span>
                <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
              </div>
              <div className="flex items-center justify-end gap-1 mt-0.5">
                <span className={`text-[10px] font-semibold border px-1.5 py-0.2 rounded ${getRoleBadgeStyle(user?.role)}`}>
                  {getRoleDisplayName(user?.role)}
                </span>
              </div>
            </div>

            <div className="w-8 h-8 rounded-full bg-slate-900 text-white font-bold text-xs flex items-center justify-center">
              {user?.name?.charAt(0) || 'U'}
            </div>

            {/* Logout button */}
            <button
              onClick={logout}
              title="Sign Out"
              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-slate-50 rounded-md transition-colors"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
