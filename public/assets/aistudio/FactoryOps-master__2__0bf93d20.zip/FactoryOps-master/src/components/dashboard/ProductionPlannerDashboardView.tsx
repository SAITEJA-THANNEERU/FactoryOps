import React, { useMemo } from 'react';
import type { Machine, ProductionRecord, Incident, WorkOrder, MaintenanceRecord, FactoryKPIs } from '../../types/index.ts';
import { useFilters } from '../../contexts/FilterContext.tsx';
import { GlobalDashboardFilters } from './GlobalDashboardFilters.tsx';
import { StatusBadge } from '../StatusBadge.tsx';
import { PriorityBadge } from '../PriorityBadge.tsx';
import {
  CalendarCheck,
  TrendingUp,
  AlertTriangle,
  ClipboardList,
  Clock,
  Layers,
  Cpu,
  Gauge,
  ArrowUpRight,
  TrendingDown,
  Percent,
  CheckCircle2,
  FileSpreadsheet
} from 'lucide-react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  ReferenceLine,
  Cell
} from 'recharts';

interface ProductionPlannerDashboardViewProps {
  machines: Machine[];
  production: ProductionRecord[];
  workOrders: WorkOrder[];
  maintenance: MaintenanceRecord[];
  kpis: FactoryKPIs | null;
  onSelectMachine: (machine: Machine) => void;
  onOpenWorkOrderModal: () => void;
}

export const ProductionPlannerDashboardView: React.FC<ProductionPlannerDashboardViewProps> = ({
  machines,
  production,
  workOrders,
  maintenance,
  kpis,
  onSelectMachine,
  onOpenWorkOrderModal
}) => {
  const {
    selectedLine,
    selectedShift,
    selectedMachine,
    timeRange
  } = useFilters();

  // 1. Filtered Machines
  const filteredMachines = useMemo(() => {
    return machines.filter(m => {
      if (selectedLine !== 'all' && m.line !== selectedLine) return false;
      if (selectedMachine !== 'all' && m.machine_id !== selectedMachine) return false;
      return true;
    });
  }, [machines, selectedLine, selectedMachine]);

  // 2. Filtered Production Records
  const filteredProduction = useMemo(() => {
    const machineIds = new Set(filteredMachines.map(m => m.machine_id));

    const now = new Date();
    let daysCutoff = 14;
    if (timeRange === 'today') daysCutoff = 1;
    else if (timeRange === '7d') daysCutoff = 7;
    else if (timeRange === '14d') daysCutoff = 14;
    else if (timeRange === 'all') daysCutoff = 365;

    const cutoffTime = now.getTime() - daysCutoff * 86400000;

    return production.filter(p => {
      if (!machineIds.has(p.machine_id)) return false;
      if (selectedShift !== 'all' && p.shift !== selectedShift) return false;
      if (selectedMachine !== 'all' && p.machine_id !== selectedMachine) return false;

      const recordTime = new Date(p.timestamp).getTime();
      return recordTime >= cutoffTime;
    });
  }, [production, filteredMachines, timeRange, selectedShift, selectedMachine]);

  // 3. 8 Critical KPI Metrics with Industrial Accounting Rules
  const plannedProduction = filteredProduction.reduce((acc, p) => acc + p.target_units, 0);
  const actualProduction = filteredProduction.reduce((acc, p) => acc + p.actual_units, 0);

  // Shortfall: planned - actual (never negative!)
  const productionShortfall = Math.max(0, plannedProduction - actualProduction);
  const productionSurplus = Math.max(0, actualProduction - plannedProduction);

  // Achievement %: (Actual / Planned) * 100 with safe division by zero
  const achievementPct = plannedProduction > 0
    ? Math.round((actualProduction / plannedProduction) * 1000) / 10
    : 0;

  const totalDefects = filteredProduction.reduce((acc, p) => acc + p.defective_units, 0);

  const avgOee = filteredMachines.length > 0
    ? Math.round((filteredMachines.reduce((acc, m) => acc + (m.oee || 0), 0) / filteredMachines.length) * 10) / 10
    : (kpis?.oee || 0);

  // Machine Downtime for filtered equipment
  const machineDowntimeHours = useMemo(() => {
    const machineIds = new Set(filteredMachines.map(m => m.machine_id));
    return maintenance
      .filter(mnt => machineIds.has(mnt.machine_id))
      .reduce((acc, mnt) => acc + (mnt.downtime_hours || 0), 0);
  }, [maintenance, filteredMachines]);

  // Open Work Orders affecting active production machines
  const openWOsOnProductionMachines = useMemo(() => {
    const machineIds = new Set(filteredMachines.map(m => m.machine_id));
    return workOrders.filter(wo => (wo.status === 'Pending' || wo.status === 'In Progress') && machineIds.has(wo.machine_id));
  }, [workOrders, filteredMachines]);

  // 4. 9 Comprehensive Visualizations

  // V1: Planned vs Actual Production (Clustered Column Chart over time)
  const plannedVsActualData = useMemo(() => {
    const map: Record<string, { date: string; planned: number; actual: number }> = {};
    filteredProduction.forEach(p => {
      const date = p.timestamp.split('T')[0].substring(5);
      if (!map[date]) map[date] = { date, planned: 0, actual: 0 };
      map[date].planned += p.target_units;
      map[date].actual += p.actual_units;
    });
    return Object.values(map).slice(-8);
  }, [filteredProduction]);

  // V2: Production Achievement Trendline (% achieved over time with 100% benchmark)
  const achievementTrendData = useMemo(() => {
    const map: Record<string, { date: string; planned: number; actual: number }> = {};
    filteredProduction.forEach(p => {
      const date = p.timestamp.split('T')[0].substring(5);
      if (!map[date]) map[date] = { date, planned: 0, actual: 0 };
      map[date].planned += p.target_units;
      map[date].actual += p.actual_units;
    });
    return Object.values(map).slice(-10).map(d => ({
      date: d.date,
      achievement: d.planned > 0 ? Math.round((d.actual / d.planned) * 100) : 0
    }));
  }, [filteredProduction]);

  // V3: Production by Machine
  const productionByMachineData = useMemo(() => {
    const map: Record<string, { machine: string; actual: number; planned: number }> = {};
    filteredProduction.forEach(p => {
      if (!map[p.machine_id]) map[p.machine_id] = { machine: p.machine_id, actual: 0, planned: 0 };
      map[p.machine_id].actual += p.actual_units;
      map[p.machine_id].planned += p.target_units;
    });
    return Object.values(map).slice(0, 8);
  }, [filteredProduction]);

  // V4: Shift-Wise Production Output
  const shiftProductionData = useMemo(() => {
    const map: Record<string, { shift: string; actual: number; planned: number; shortfall: number }> = {
      Morning: { shift: 'Morning', actual: 0, planned: 0, shortfall: 0 },
      Afternoon: { shift: 'Afternoon', actual: 0, planned: 0, shortfall: 0 },
      Night: { shift: 'Night', actual: 0, planned: 0, shortfall: 0 }
    };
    filteredProduction.forEach(p => {
      if (map[p.shift]) {
        map[p.shift].actual += p.actual_units;
        map[p.shift].planned += p.target_units;
      }
    });
    Object.values(map).forEach(s => {
      s.shortfall = Math.max(0, s.planned - s.actual);
    });
    return Object.values(map);
  }, [filteredProduction]);

  // V5: Production Shortfall Visual (Machines/shifts with deficit)
  const shortfallByMachineData = useMemo(() => {
    const map: Record<string, { machine: string; shortfall: number; actual: number; planned: number }> = {};
    filteredProduction.forEach(p => {
      if (!map[p.machine_id]) map[p.machine_id] = { machine: p.machine_id, shortfall: 0, actual: 0, planned: 0 };
      map[p.machine_id].actual += p.actual_units;
      map[p.machine_id].planned += p.target_units;
    });
    return Object.values(map)
      .map(item => ({
        machine: item.machine,
        shortfall: Math.max(0, item.planned - item.actual),
        planned: item.planned,
        actual: item.actual
      }))
      .filter(item => item.shortfall > 0)
      .sort((a, b) => b.shortfall - a.shortfall);
  }, [filteredProduction]);

  // V6: Defect & Scrap Trends Over Time
  const defectTrendData = useMemo(() => {
    const dateMap: Record<string, { date: string; defects: number; scrapKg: number }> = {};
    filteredProduction.forEach(p => {
      const date = p.timestamp.split('T')[0].substring(5);
      if (!dateMap[date]) dateMap[date] = { date, defects: 0, scrapKg: 0 };
      dateMap[date].defects += p.defective_units;
      dateMap[date].scrapKg += Math.round(p.scrap_kg);
    });
    return Object.values(dateMap).slice(-8);
  }, [filteredProduction]);

  // V7: Machine Downtime Analysis
  const downtimeAnalysisData = useMemo(() => {
    const map: Record<string, number> = {};
    maintenance.forEach(mnt => {
      map[mnt.machine_id] = (map[mnt.machine_id] || 0) + mnt.downtime_hours;
    });
    return Object.entries(map)
      .map(([machine, hours]) => ({ machine, hours }))
      .sort((a, b) => b.hours - a.hours)
      .slice(0, 6);
  }, [maintenance]);

  // V8: OEE Trend Over Time
  const oeeTrendData = useMemo(() => {
    const dateMap: Record<string, { date: string; sum: number; count: number }> = {};
    filteredProduction.forEach(p => {
      const date = p.timestamp.split('T')[0].substring(5);
      if (!dateMap[date]) dateMap[date] = { date, sum: 0, count: 0 };
      const ratio = p.target_units > 0 ? (p.actual_units / p.target_units) * 88 : 82;
      dateMap[date].sum += ratio;
      dateMap[date].count++;
    });
    return Object.values(dateMap).slice(-8).map(d => ({
      date: d.date,
      oee: Math.min(100, Math.round((d.sum / d.count) * 10) / 10)
    }));
  }, [filteredProduction]);

  // V9: Work Order Impact
  const workOrderImpactData = useMemo(() => {
    const map: Record<string, number> = {};
    openWOsOnProductionMachines.forEach(wo => {
      map[wo.machine_id] = (map[wo.machine_id] || 0) + 1;
    });
    return Object.entries(map).map(([machine, count]) => ({ machine, count }));
  }, [openWOsOnProductionMachines]);

  // 5 Operational Tables Data

  // Table 1: Planned vs Actual Production Details
  const productionDetailsList = useMemo(() => {
    return filteredProduction.slice(0, 8).map(p => {
      const shortfall = Math.max(0, p.target_units - p.actual_units);
      const ach = p.target_units > 0 ? Math.round((p.actual_units / p.target_units) * 100) : 0;
      return {
        ...p,
        shortfall,
        achievement: ach
      };
    });
  }, [filteredProduction]);

  // Table 2: Machines with Production Shortfalls
  const shortfallMachinesList = useMemo(() => {
    return shortfallByMachineData.slice(0, 5);
  }, [shortfallByMachineData]);

  // Table 3: Shift Summary
  const shiftSummary = useMemo(() => {
    return shiftProductionData.map(s => {
      const ach = s.planned > 0 ? Math.round((s.actual / s.planned) * 100) : 0;
      return {
        ...s,
        achievement: ach
      };
    });
  }, [shiftProductionData]);

  // Table 4: Significant Downtime Machines
  const significantDowntimeMachines = useMemo(() => {
    return downtimeAnalysisData.filter(d => d.hours > 0).slice(0, 5);
  }, [downtimeAnalysisData]);

  return (
    <div className="space-y-6">
      {/* Title & Actions */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Production Planning & Capacity Intelligence
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Target yield vs actual output, shortfall gap analysis, line quotas & operational bottlenecks
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenWorkOrderModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-md shadow-2xs transition-colors"
          >
            <ClipboardList className="w-3.5 h-3.5 text-emerald-400" />
            <span>Schedule Line Maintenance</span>
          </button>
        </div>
      </div>

      {/* Global Filter Bar */}
      <GlobalDashboardFilters
        machines={machines}
        showStatusFilter={false}
      />

      {/* 8 KPI Cards (Production Planner Requirements) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {/* KPI 1: Planned Production */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
            Planned Quota
          </div>
          <div className="text-lg font-bold font-mono text-slate-800 tabular-nums">
            {plannedProduction.toLocaleString()}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Target units</p>
        </div>

        {/* KPI 2: Actual Production */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-blue-700 uppercase tracking-wider mb-1">
            Actual Output
          </div>
          <div className="text-lg font-bold font-mono text-blue-700 tabular-nums">
            {actualProduction.toLocaleString()}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Produced units</p>
        </div>

        {/* KPI 3: Production Shortfall (Strict: Max(0, Planned - Actual)) */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-rose-700 uppercase tracking-wider mb-1">
            Shortfall Gap
          </div>
          <div className="text-lg font-bold font-mono text-rose-700 tabular-nums">
            {productionShortfall.toLocaleString()}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">
            {productionSurplus > 0 ? `+${productionSurplus} surplus` : 'Deficit units'}
          </p>
        </div>

        {/* KPI 4: Production Achievement % */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider mb-1">
            Achievement %
          </div>
          <div className="text-lg font-bold font-mono text-emerald-700 tabular-nums">
            {achievementPct}%
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Quota fulfilled</p>
        </div>

        {/* KPI 5: Total Defects */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-amber-700 uppercase tracking-wider mb-1">
            Defect Units
          </div>
          <div className="text-lg font-bold font-mono text-slate-900 tabular-nums">
            {totalDefects}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Scrap / rejects</p>
        </div>

        {/* KPI 6: OEE */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider mb-1">
            Efficiency OEE
          </div>
          <div className="text-lg font-bold font-mono text-slate-900 tabular-nums">
            {avgOee}%
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Plant factor</p>
        </div>

        {/* KPI 7: Machine Downtime */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider mb-1">
            Downtime Hours
          </div>
          <div className="text-lg font-bold font-mono text-slate-900 tabular-nums">
            {machineDowntimeHours}h
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Line interruption</p>
        </div>

        {/* KPI 8: Open Work Orders Affecting Production */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-purple-700 uppercase tracking-wider mb-1">
            Impacting WOs
          </div>
          <div className="text-lg font-bold font-mono text-purple-700 tabular-nums">
            {openWOsOnProductionMachines.length}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">On active lines</p>
        </div>
      </div>

      {/* Visualizations Grid Row 1 (Visuals 1 & 2) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* V1: Planned vs Actual Production (Clustered Column Chart) */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Planned vs Actual Production by Date</h2>
              <p className="text-xs text-slate-500">Clustered column comparison across shifts</p>
            </div>
            <span className="text-xs font-mono text-slate-400">Units</span>
          </div>
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={plannedVsActualData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '6px' }} />
                <Bar dataKey="planned" name="Planned Target" fill="#cbd5e1" radius={[2, 2, 0, 0]} />
                <Bar dataKey="actual" name="Actual Produced" fill="#2563eb" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* V2: Production Achievement Trendline */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Production Achievement Trendline (% of Target)</h2>
              <p className="text-xs text-slate-500">Percentage quota achieved against 100% benchmark</p>
            </div>
            <span className="text-xs font-mono text-emerald-700">Benchmark 100%</span>
          </div>
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={achievementTrendData} margin={{ top: 10, right: 15, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis domain={[60, 115]} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                  formatter={(val: any) => [`${val}%`, 'Achievement']}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '6px' }} />
                <ReferenceLine y={100} stroke="#dc2626" strokeDasharray="3 3" label={{ value: '100% Target', fill: '#dc2626', fontSize: 10 }} />
                <Line type="monotone" dataKey="achievement" name="Achievement %" stroke="#059669" strokeWidth={2.5} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Visualizations Grid Row 2 (Visuals 3, 4 & 5) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* V3: Production by Machine */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Production by Machine</h2>
          <p className="text-xs text-slate-500 mb-2">Planned vs actual comparison across units</p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={productionByMachineData} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="machine" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '10px' }} />
                <Bar dataKey="planned" name="Target" fill="#cbd5e1" radius={[2, 2, 0, 0]} />
                <Bar dataKey="actual" name="Actual" fill="#2563eb" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* V4: Shift-Wise Production */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Shift-Wise Production Output</h2>
          <p className="text-xs text-slate-500 mb-2">Morning, Afternoon & Night yield distribution</p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={shiftProductionData} margin={{ top: 5, right: 5, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="shift" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '10px' }} />
                <Bar dataKey="actual" name="Produced" fill="#10b981" radius={[2, 2, 0, 0]} />
                <Bar dataKey="shortfall" name="Shortfall" fill="#ef4444" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* V5: Production Shortfall Analysis */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Production Shortfall by Machine</h2>
          <p className="text-xs text-slate-500 mb-2">Deficit gaps where actual &lt; planned</p>
          <div className="h-52">
            {shortfallByMachineData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={shortfallByMachineData.slice(0, 5)} layout="vertical" margin={{ top: 5, right: 15, left: 15, bottom: 0 }}>
                  <XAxis type="number" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <YAxis dataKey="machine" type="category" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} width={65} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                    formatter={(val: any) => [`${val} units`, 'Shortfall Deficit']}
                  />
                  <Bar dataKey="shortfall" name="Shortfall Units" fill="#dc2626" radius={[0, 3, 3, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-xs text-emerald-600">
                <CheckCircle2 className="w-6 h-6 mb-1 text-emerald-500" />
                <span>Zero Shortfalls! All production met or exceeded quota.</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Visualizations Grid Row 3 (Visuals 6, 7, 8 & 9) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* V6: Defect Trend */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Defects & Scrap Trend</h2>
          <p className="text-xs text-slate-500 mb-2">Quality losses over time</p>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={defectTrendData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="defects" name="Defects" stroke="#f59e0b" fill="#fef3c7" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* V7: Machine Downtime Analysis */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Equipment Downtime</h2>
          <p className="text-xs text-slate-500 mb-2">Recorded downtime hours</p>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={downtimeAnalysisData} layout="vertical" margin={{ top: 5, right: 15, left: 15, bottom: 0 }}>
                <XAxis type="number" hide />
                <YAxis dataKey="machine" type="category" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} width={65} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                  formatter={(val: any) => [`${val} hrs`, 'Downtime']}
                />
                <Bar dataKey="hours" name="Downtime" fill="#ef4444" radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* V8: OEE Trend */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">OEE Efficiency Trend</h2>
          <p className="text-xs text-slate-500 mb-2">Production yield factor</p>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={oeeTrendData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis domain={[65, 100]} tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                  formatter={(val: any) => [`${val}%`, 'OEE']}
                />
                <Line type="monotone" dataKey="oee" name="OEE %" stroke="#059669" strokeWidth={2} dot={{ r: 2 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* V9: Work Order Impact */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Work Order Impact</h2>
          <p className="text-xs text-slate-500 mb-2">Open maintenance on lines</p>
          <div className="h-44">
            {workOrderImpactData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={workOrderImpactData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="machine" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                  />
                  <Bar dataKey="count" name="Open WOs" fill="#8b5cf6" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                No active maintenance affecting lines.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Operational Tables: 5 Production Planner Tables */}
      <div className="space-y-6">
        {/* Table 1: Planned vs Actual Production Details */}
        <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Planned vs Actual Production Details</h2>
              <p className="text-xs text-slate-500">Shift record breakdown with shortfall calculations and achievement %</p>
            </div>
            <span className="text-xs text-slate-500 font-mono">{filteredProduction.length} Shift Records</span>
          </div>
          <div className="overflow-x-auto max-h-72">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 sticky top-0">
                <tr>
                  <th className="px-3 py-2 font-semibold">Date & Shift</th>
                  <th className="px-3 py-2 font-semibold">Machine</th>
                  <th className="px-3 py-2 font-semibold">Target Units</th>
                  <th className="px-3 py-2 font-semibold">Actual Units</th>
                  <th className="px-3 py-2 font-semibold">Shortfall</th>
                  <th className="px-3 py-2 font-semibold">Achievement %</th>
                  <th className="px-3 py-2 font-semibold">Defects</th>
                  <th className="px-3 py-2 font-semibold">Operator</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {productionDetailsList.map(p => (
                  <tr key={p.id} className="hover:bg-slate-50">
                    <td className="px-3 py-2.5 text-slate-700">
                      <span className="font-mono">{p.timestamp.split('T')[0]}</span>
                      <span className="text-slate-400 ml-1.5 font-medium">({p.shift})</span>
                    </td>
                    <td className="px-3 py-2.5 font-mono font-bold text-slate-900">{p.machine_id}</td>
                    <td className="px-3 py-2.5 font-mono tabular-nums text-slate-600">{p.target_units}</td>
                    <td className="px-3 py-2.5 font-mono tabular-nums font-bold text-slate-900">{p.actual_units}</td>
                    <td className="px-3 py-2.5 font-mono tabular-nums">
                      {p.shortfall > 0 ? (
                        <span className="text-rose-600 font-bold">-{p.shortfall}</span>
                      ) : (
                        <span className="text-emerald-700 font-medium">0 (Target Met)</span>
                      )}
                    </td>
                    <td className="px-3 py-2.5 font-mono tabular-nums">
                      <span className={`px-1.5 py-0.5 rounded text-[11px] font-semibold ${
                        p.achievement >= 100 ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-800'
                      }`}>
                        {p.achievement}%
                      </span>
                    </td>
                    <td className="px-3 py-2.5 font-mono tabular-nums text-slate-600">{p.defective_units}</td>
                    <td className="px-3 py-2.5 text-slate-600">{p.operator}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* 2-Column Split: Shortfall Machines & Shift Summary */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Table 2: Machines with Production Shortfalls */}
          <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
            <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <TrendingDown className="w-4 h-4 text-rose-600" />
                <h2 className="text-sm font-bold text-slate-900">Machines with Production Shortfalls</h2>
              </div>
              <span className="text-xs text-rose-600 font-mono font-semibold">Priority Gap</span>
            </div>
            <div className="overflow-x-auto max-h-60">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 sticky top-0">
                  <tr>
                    <th className="px-3 py-2 font-semibold">Machine ID</th>
                    <th className="px-3 py-2 font-semibold">Planned</th>
                    <th className="px-3 py-2 font-semibold">Actual Output</th>
                    <th className="px-3 py-2 font-semibold">Shortfall Deficit</th>
                    <th className="px-3 py-2 font-semibold text-right">Inspect</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {shortfallMachinesList.map(s => (
                    <tr key={s.machine} className="hover:bg-slate-50">
                      <td className="px-3 py-2.5 font-mono font-bold text-slate-900">{s.machine}</td>
                      <td className="px-3 py-2.5 font-mono tabular-nums text-slate-600">{s.planned}</td>
                      <td className="px-3 py-2.5 font-mono tabular-nums text-slate-800">{s.actual}</td>
                      <td className="px-3 py-2.5 font-mono tabular-nums font-bold text-rose-600">-{s.shortfall} units</td>
                      <td className="px-3 py-2.5 text-right">
                        <button
                          onClick={() => {
                            const found = machines.find(m => m.machine_id === s.machine);
                            if (found) onSelectMachine(found);
                          }}
                          className="px-2 py-0.5 text-[11px] font-semibold text-emerald-700 hover:text-emerald-900 bg-emerald-50 rounded"
                        >
                          Details
                        </button>
                      </td>
                    </tr>
                  ))}
                  {shortfallMachinesList.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-4 py-6 text-center text-emerald-600 text-xs">
                        All machines achieved their production quota!
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Table 3: Shift-Wise Production Summary */}
          <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
            <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">Shift-Wise Production Summary</h2>
              <span className="text-xs text-slate-500 font-mono">3 Operating Shifts</span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                  <tr>
                    <th className="px-3 py-2.5 font-semibold">Shift</th>
                    <th className="px-3 py-2.5 font-semibold">Planned</th>
                    <th className="px-3 py-2.5 font-semibold">Actual</th>
                    <th className="px-3 py-2.5 font-semibold">Shortfall</th>
                    <th className="px-3 py-2.5 font-semibold">Achievement</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {shiftSummary.map(s => (
                    <tr key={s.shift} className="hover:bg-slate-50">
                      <td className="px-3 py-2.5 font-semibold text-slate-900">{s.shift} Shift</td>
                      <td className="px-3 py-2.5 font-mono tabular-nums text-slate-600">{s.planned.toLocaleString()}</td>
                      <td className="px-3 py-2.5 font-mono tabular-nums font-bold text-slate-900">{s.actual.toLocaleString()}</td>
                      <td className="px-3 py-2.5 font-mono tabular-nums">
                        {s.shortfall > 0 ? (
                          <span className="text-rose-600 font-bold">-{s.shortfall.toLocaleString()}</span>
                        ) : (
                          <span className="text-emerald-700">0</span>
                        )}
                      </td>
                      <td className="px-3 py-2.5 font-mono tabular-nums font-semibold text-emerald-700">{s.achievement}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* 2-Column Split: Significant Downtime Machines & Production-Related Work Orders */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Table 4: Machines with Significant Downtime */}
          <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
            <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">Machines with Recorded Downtime</h2>
              <span className="text-xs text-slate-500 font-mono">Downtime Losses</span>
            </div>
            <div className="overflow-x-auto max-h-60">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 sticky top-0">
                  <tr>
                    <th className="px-3 py-2 font-semibold">Machine ID</th>
                    <th className="px-3 py-2 font-semibold">Downtime Hours</th>
                    <th className="px-3 py-2 font-semibold text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {significantDowntimeMachines.map(d => (
                    <tr key={d.machine} className="hover:bg-slate-50">
                      <td className="px-3 py-2.5 font-mono font-bold text-slate-900">{d.machine}</td>
                      <td className="px-3 py-2.5 font-mono text-slate-800">{d.hours} hours outage</td>
                      <td className="px-3 py-2.5 text-right">
                        <button
                          onClick={() => {
                            const found = machines.find(m => m.machine_id === d.machine);
                            if (found) onSelectMachine(found);
                          }}
                          className="px-2 py-0.5 text-[11px] font-semibold text-emerald-700 hover:text-emerald-900 bg-emerald-50 rounded"
                        >
                          Inspect Line
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Table 5: Production-Related Work Orders */}
          <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
            <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">Production-Impacting Work Orders</h2>
              <span className="text-xs text-slate-500 font-mono">{openWOsOnProductionMachines.length} Orders</span>
            </div>
            <div className="overflow-x-auto max-h-60">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 sticky top-0">
                  <tr>
                    <th className="px-3 py-2 font-semibold">Order ID</th>
                    <th className="px-3 py-2 font-semibold">Machine</th>
                    <th className="px-3 py-2 font-semibold">Priority</th>
                    <th className="px-3 py-2 font-semibold">Status</th>
                    <th className="px-3 py-2 font-semibold">Due</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {openWOsOnProductionMachines.map(wo => (
                    <tr key={wo.id} className="hover:bg-slate-50">
                      <td className="px-3 py-2.5 font-mono font-medium text-slate-900">{wo.work_order_id}</td>
                      <td className="px-3 py-2.5 font-mono text-slate-700">{wo.machine_id}</td>
                      <td className="px-3 py-2.5"><PriorityBadge priority={wo.priority} /></td>
                      <td className="px-3 py-2.5">
                        <span className="px-1.5 py-0.5 rounded text-[11px] font-semibold bg-amber-50 text-amber-800">
                          {wo.status}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 font-mono text-slate-500">{wo.due_date}</td>
                    </tr>
                  ))}
                  {openWOsOnProductionMachines.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-4 py-6 text-center text-slate-400 text-xs">
                        No open work orders impacting active production machines.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
