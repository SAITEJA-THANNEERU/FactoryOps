import React, { useMemo } from 'react';
import type { Machine, ProductionRecord, Incident, WorkOrder, MaintenanceRecord, FactoryKPIs } from '../../types/index.ts';
import { useFilters } from '../../contexts/FilterContext.tsx';
import { GlobalDashboardFilters } from './GlobalDashboardFilters.tsx';
import { StatusBadge } from '../StatusBadge.tsx';
import { SeverityBadge } from '../SeverityBadge.tsx';
import { PriorityBadge } from '../PriorityBadge.tsx';
import {
  TrendingUp,
  Cpu,
  AlertTriangle,
  ClipboardList,
  Clock,
  Gauge,
  Layers,
  ArrowUpRight,
  Plus,
  Flame,
  CheckCircle2,
  Calendar
} from 'lucide-react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  ReferenceLine
} from 'recharts';

interface ManagerDashboardViewProps {
  machines: Machine[];
  production: ProductionRecord[];
  incidents: Incident[];
  workOrders: WorkOrder[];
  maintenance: MaintenanceRecord[];
  kpis: FactoryKPIs | null;
  onSelectMachine: (machine: Machine) => void;
  onOpenIncidentModal: () => void;
  onOpenWorkOrderModal: () => void;
}

export const ManagerDashboardView: React.FC<ManagerDashboardViewProps> = ({
  machines,
  production,
  incidents,
  workOrders,
  maintenance,
  kpis,
  onSelectMachine,
  onOpenIncidentModal,
  onOpenWorkOrderModal
}) => {
  const {
    selectedLine,
    selectedShift,
    selectedMachine,
    selectedSeverity,
    selectedWorkOrderStatus,
    timeRange
  } = useFilters();

  // 1. Filtered Machines
  const filteredMachines = useMemo(() => {
    return machines.filter(m => {
      if (selectedLine !== 'all' && m.line !== selectedLine) return false;
      if (selectedMachine !== 'all' && m.machine_id !== selectedMachine) return false;
      return true;
    });
  }, [machines, selectedLine, selectedMachine]);

  // 2. Filtered Production Records
  const filteredProduction = useMemo(() => {
    const machineIds = new Set(filteredMachines.map(m => m.machine_id));

    const now = new Date();
    let daysCutoff = 14;
    if (timeRange === 'today') daysCutoff = 1;
    else if (timeRange === '7d') daysCutoff = 7;
    else if (timeRange === '14d') daysCutoff = 14;
    else if (timeRange === 'all') daysCutoff = 365;

    const cutoffTime = now.getTime() - daysCutoff * 86400000;

    return production.filter(p => {
      if (!machineIds.has(p.machine_id)) return false;
      if (selectedShift !== 'all' && p.shift !== selectedShift) return false;
      if (selectedMachine !== 'all' && p.machine_id !== selectedMachine) return false;

      const recordTime = new Date(p.timestamp).getTime();
      return recordTime >= cutoffTime;
    });
  }, [production, filteredMachines, timeRange, selectedShift, selectedMachine]);

  // 3. Filtered Incidents
  const filteredIncidents = useMemo(() => {
    const machineIds = new Set(filteredMachines.map(m => m.machine_id));
    return incidents.filter(inc => {
      if (!machineIds.has(inc.machine_id)) return false;
      if (selectedMachine !== 'all' && inc.machine_id !== selectedMachine) return false;
      if (selectedSeverity !== 'all' && inc.severity !== selectedSeverity) return false;
      return true;
    });
  }, [incidents, filteredMachines, selectedMachine, selectedSeverity]);

  // 4. Filtered Work Orders
  const filteredWorkOrders = useMemo(() => {
    const machineIds = new Set(filteredMachines.map(m => m.machine_id));
    return workOrders.filter(wo => {
      if (!machineIds.has(wo.machine_id)) return false;
      if (selectedMachine !== 'all' && wo.machine_id !== selectedMachine) return false;
      if (selectedWorkOrderStatus !== 'all' && wo.status !== selectedWorkOrderStatus) return false;
      return true;
    });
  }, [workOrders, filteredMachines, selectedMachine, selectedWorkOrderStatus]);

  // 5. 8 KPI Metrics (Strict Calculations)
  const plannedProduction = filteredProduction.reduce((acc, p) => acc + p.target_units, 0);
  const actualProduction = filteredProduction.reduce((acc, p) => acc + p.actual_units, 0);
  const achievementPct = plannedProduction > 0 ? Math.round((actualProduction / plannedProduction) * 1000) / 10 : 0;

  const avgOee = filteredMachines.length > 0
    ? Math.round((filteredMachines.reduce((acc, m) => acc + (m.oee || 0), 0) / filteredMachines.length) * 10) / 10
    : (kpis?.oee || 0);

  const totalDefects = filteredProduction.reduce((acc, p) => acc + p.defective_units, 0);
  const activeIncidents = filteredIncidents.filter(i => i.status === 'Open' || i.status === 'Investigating').length;
  const pendingWorkOrders = filteredWorkOrders.filter(w => w.status === 'Pending').length;

  // Machine Downtime from maintenance records of these machines
  const machineDowntimeHours = useMemo(() => {
    const machineIds = new Set(filteredMachines.map(m => m.machine_id));
    return maintenance
      .filter(mnt => machineIds.has(mnt.machine_id))
      .reduce((acc, mnt) => acc + (mnt.downtime_hours || 0), 0);
  }, [maintenance, filteredMachines]);

  // 6. 8 Visualizations

  // V1: Planned vs Actual Production (by date)
  const plannedVsActualData = useMemo(() => {
    const map: Record<string, { date: string; planned: number; actual: number }> = {};
    filteredProduction.forEach(p => {
      const date = p.timestamp.split('T')[0].substring(5);
      if (!map[date]) map[date] = { date, planned: 0, actual: 0 };
      map[date].planned += p.target_units;
      map[date].actual += p.actual_units;
    });
    return Object.values(map).slice(-7);
  }, [filteredProduction]);

  // V2: Production Achievement Trendline (% achieved by date)
  const achievementTrendData = useMemo(() => {
    const map: Record<string, { date: string; planned: number; actual: number }> = {};
    filteredProduction.forEach(p => {
      const date = p.timestamp.split('T')[0].substring(5);
      if (!map[date]) map[date] = { date, planned: 0, actual: 0 };
      map[date].planned += p.target_units;
      map[date].actual += p.actual_units;
    });
    return Object.values(map)
      .slice(-10)
      .map(entry => ({
        date: entry.date,
        achievement: entry.planned > 0 ? Math.round((entry.actual / entry.planned) * 100) : 0,
        targetBenchmark: 100
      }));
  }, [filteredProduction]);

  // V3: Machine Performance (Production units and OEE across machines)
  const machinePerformanceData = useMemo(() => {
    const prodByMachine: Record<string, number> = {};
    filteredProduction.forEach(p => {
      prodByMachine[p.machine_id] = (prodByMachine[p.machine_id] || 0) + p.actual_units;
    });
    return filteredMachines.slice(0, 8).map(m => ({
      machine: m.machine_id,
      production: prodByMachine[m.machine_id] || 0,
      oee: m.oee
    }));
  }, [filteredMachines, filteredProduction]);

  // V4: Defect Analysis by Machine
  const defectByMachineData = useMemo(() => {
    const map: Record<string, number> = {};
    filteredProduction.forEach(p => {
      map[p.machine_id] = (map[p.machine_id] || 0) + p.defective_units;
    });
    return Object.entries(map)
      .map(([machine, defects]) => ({ machine, defects }))
      .sort((a, b) => b.defects - a.defects)
      .slice(0, 6);
  }, [filteredProduction]);

  // V5: Downtime Analysis by Machine
  const downtimeByMachineData = useMemo(() => {
    const map: Record<string, number> = {};
    maintenance.forEach(mnt => {
      map[mnt.machine_id] = (map[mnt.machine_id] || 0) + mnt.downtime_hours;
    });
    return Object.entries(map)
      .map(([machine, hours]) => ({ machine, hours: Math.round(hours * 10) / 10 }))
      .sort((a, b) => b.hours - a.hours)
      .slice(0, 6);
  }, [maintenance]);

  // V6: Incident Monitoring (Severity & Status grouping)
  const incidentsMonitoringData = useMemo(() => {
    const map: Record<string, { severity: string; open: number; resolved: number }> = {
      Critical: { severity: 'Critical', open: 0, resolved: 0 },
      High: { severity: 'High', open: 0, resolved: 0 },
      Medium: { severity: 'Medium', open: 0, resolved: 0 },
      Low: { severity: 'Low', open: 0, resolved: 0 }
    };
    filteredIncidents.forEach(inc => {
      if (map[inc.severity]) {
        if (inc.status === 'Open' || inc.status === 'Investigating') {
          map[inc.severity].open++;
        } else {
          map[inc.severity].resolved++;
        }
      }
    });
    return Object.values(map);
  }, [filteredIncidents]);

  // V7: Shift Performance
  const shiftPerformanceData = useMemo(() => {
    const map: Record<string, { shift: string; actual: number; planned: number; defects: number }> = {
      Morning: { shift: 'Morning', actual: 0, planned: 0, defects: 0 },
      Afternoon: { shift: 'Afternoon', actual: 0, planned: 0, defects: 0 },
      Night: { shift: 'Night', actual: 0, planned: 0, defects: 0 }
    };
    filteredProduction.forEach(p => {
      if (map[p.shift]) {
        map[p.shift].actual += p.actual_units;
        map[p.shift].planned += p.target_units;
        map[p.shift].defects += p.defective_units;
      }
    });
    return Object.values(map);
  }, [filteredProduction]);

  // V8: OEE Trend Over Time (Derived from production cycle & defects)
  const oeeTrendData = useMemo(() => {
    const dateMap: Record<string, { date: string; sumOee: number; count: number }> = {};
    filteredProduction.forEach(p => {
      const date = p.timestamp.split('T')[0].substring(5);
      if (!dateMap[date]) dateMap[date] = { date, sumOee: 0, count: 0 };
      // OEE calculation proxy from yield ratio
      const eff = p.target_units > 0 ? (p.actual_units / p.target_units) * 85 : 80;
      dateMap[date].sumOee += eff;
      dateMap[date].count++;
    });
    return Object.values(dateMap).slice(-8).map(d => ({
      date: d.date,
      oee: Math.min(100, Math.round((d.sumOee / d.count) * 10) / 10)
    }));
  }, [filteredProduction]);

  // Machines requiring attention (warning, maintenance, or low health score)
  const machinesAttention = useMemo(() => {
    return machines.filter(m => m.status !== 'running' || m.health_score < 75);
  }, [machines]);

  return (
    <div className="space-y-6">
      {/* Title & Actions */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Operations & Shift Command Center
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Day-to-day floor operations, target achievement, equipment diagnostics & bottleneck resolution
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenIncidentModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 text-xs font-semibold rounded-md shadow-2xs transition-colors"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
            <span>Log Floor Anomaly</span>
          </button>
          <button
            onClick={onOpenWorkOrderModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-md shadow-2xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-emerald-400" />
            <span>Create Work Order</span>
          </button>
        </div>
      </div>

      {/* Global Filter Bar */}
      <GlobalDashboardFilters
        machines={machines}
        showSeverityFilter={true}
        showWorkOrderStatusFilter={true}
      />

      {/* 8 KPI Cards (Manager / Supervisor) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {/* KPI 1: Planned Production */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-1">
            Planned Output
          </div>
          <div className="text-lg font-bold font-mono text-slate-800 tabular-nums">
            {plannedProduction.toLocaleString()}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Target units</p>
        </div>

        {/* KPI 2: Actual Production */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-blue-700 uppercase tracking-wider mb-1">
            Actual Output
          </div>
          <div className="text-lg font-bold font-mono text-blue-700 tabular-nums">
            {actualProduction.toLocaleString()}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Completed units</p>
        </div>

        {/* KPI 3: Achievement % */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider mb-1">
            Achievement
          </div>
          <div className="text-lg font-bold font-mono text-emerald-700 tabular-nums">
            {achievementPct}%
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Target fulfillment</p>
        </div>

        {/* KPI 4: OEE */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider mb-1">
            Floor OEE
          </div>
          <div className="text-lg font-bold font-mono text-slate-900 tabular-nums">
            {avgOee}%
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Overall effectiveness</p>
        </div>

        {/* KPI 5: Total Defects */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-amber-700 uppercase tracking-wider mb-1">
            Defects
          </div>
          <div className="text-lg font-bold font-mono text-slate-900 tabular-nums">
            {totalDefects}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Rejection count</p>
        </div>

        {/* KPI 6: Active Incidents */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-rose-700 uppercase tracking-wider mb-1">
            Incidents
          </div>
          <div className="text-lg font-bold font-mono text-rose-700 tabular-nums">
            {activeIncidents}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Active triage</p>
        </div>

        {/* KPI 7: Pending Work Orders */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-purple-700 uppercase tracking-wider mb-1">
            Pending WOs
          </div>
          <div className="text-lg font-bold font-mono text-slate-900 tabular-nums">
            {pendingWorkOrders}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Maintenance queue</p>
        </div>

        {/* KPI 8: Machine Downtime */}
        <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs">
          <div className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider mb-1">
            Downtime
          </div>
          <div className="text-lg font-bold font-mono text-slate-900 tabular-nums">
            {machineDowntimeHours}h
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">Recorded outage</p>
        </div>
      </div>

      {/* Visualizations Grid Row 1 (Visuals 1 & 2) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* V1: Planned vs Actual Production */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Planned vs Actual Output by Day</h2>
              <p className="text-xs text-slate-500">Target against completed production output</p>
            </div>
            <span className="text-xs font-mono text-slate-400">Units</span>
          </div>
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={plannedVsActualData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '6px' }} />
                <Bar dataKey="planned" name="Planned" fill="#cbd5e1" radius={[2, 2, 0, 0]} />
                <Bar dataKey="actual" name="Actual" fill="#0284c7" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* V2: Production Achievement Trend */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Production Achievement Trend (% Fulfillment)</h2>
              <p className="text-xs text-slate-500">Daily target fulfillment against 100% quota benchmark</p>
            </div>
            <span className="text-xs font-mono text-emerald-700">100% Target</span>
          </div>
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={achievementTrendData} margin={{ top: 10, right: 15, left: -15, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis domain={[50, 120]} tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                  formatter={(val: any) => [`${val}%`, 'Achievement']}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '6px' }} />
                <ReferenceLine y={100} stroke="#dc2626" strokeDasharray="3 3" label={{ value: '100% Target', fill: '#dc2626', fontSize: 10 }} />
                <Line type="monotone" dataKey="achievement" name="Actual %" stroke="#059669" strokeWidth={2.5} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Visualizations Grid Row 2 (Visuals 3 & 4 & 5) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* V3: Machine Performance */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Machine Performance Output</h2>
          <p className="text-xs text-slate-500 mb-2">Total units produced by equipment</p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={machinePerformanceData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="machine" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                />
                <Bar dataKey="production" name="Output Units" fill="#3b82f6" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* V4: Defect Analysis by Machine */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Defect Analysis by Machine</h2>
          <p className="text-xs text-slate-500 mb-2">Top units generating quality non-conformances</p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={defectByMachineData} layout="vertical" margin={{ top: 5, right: 15, left: 15, bottom: 0 }}>
                <XAxis type="number" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis dataKey="machine" type="category" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} width={65} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                />
                <Bar dataKey="defects" name="Defects" fill="#f59e0b" radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* V5: Downtime Analysis by Machine */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Equipment Downtime Hours</h2>
          <p className="text-xs text-slate-500 mb-2">Recorded maintenance and outage hours</p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={downtimeByMachineData} layout="vertical" margin={{ top: 5, right: 15, left: 15, bottom: 0 }}>
                <XAxis type="number" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis dataKey="machine" type="category" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} width={65} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                  formatter={(val: any) => [`${val} hrs`, 'Downtime']}
                />
                <Bar dataKey="hours" name="Downtime (hrs)" fill="#ef4444" radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Visualizations Grid Row 3 (Visuals 6, 7 & 8) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* V6: Incident Monitoring */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Incident Risk Monitoring</h2>
          <p className="text-xs text-slate-500 mb-2">Open vs resolved incident breakdown</p>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={incidentsMonitoringData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="severity" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '10px' }} />
                <Bar dataKey="open" name="Active / Open" fill="#dc2626" radius={[2, 2, 0, 0]} />
                <Bar dataKey="resolved" name="Resolved" fill="#059669" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* V7: Shift Performance */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Shift Performance Comparison</h2>
          <p className="text-xs text-slate-500 mb-2">Morning, Afternoon & Night unit yield</p>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={shiftPerformanceData} margin={{ top: 5, right: 5, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="shift" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '10px' }} />
                <Bar dataKey="actual" name="Actual Yield" fill="#10b981" radius={[2, 2, 0, 0]} />
                <Bar dataKey="planned" name="Shift Quota" fill="#94a3b8" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* V8: OEE Trend */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Floor OEE Trendline</h2>
          <p className="text-xs text-slate-500 mb-2">Operational continuity & efficiency proxy</p>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={oeeTrendData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="oeeFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis domain={[60, 100]} tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                  formatter={(val: any) => [`${val}%`, 'OEE']}
                />
                <Area type="monotone" dataKey="oee" name="OEE %" stroke="#059669" fillOpacity={1} fill="url(#oeeFill)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Operational Tables (4 Tables) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Table 1: Machines Requiring Attention */}
        <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <h2 className="text-sm font-bold text-slate-900">Machines Requiring Attention</h2>
            </div>
            <span className="text-xs text-slate-500 font-mono">{machinesAttention.length} Units</span>
          </div>
          <div className="overflow-x-auto max-h-64">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 sticky top-0">
                <tr>
                  <th className="px-3 py-2 font-semibold">Machine</th>
                  <th className="px-3 py-2 font-semibold">Status</th>
                  <th className="px-3 py-2 font-semibold">Health</th>
                  <th className="px-3 py-2 font-semibold">Vibration</th>
                  <th className="px-3 py-2 font-semibold text-right">Drill-Down</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {machinesAttention.map(m => (
                  <tr key={m.id} className="hover:bg-slate-50">
                    <td className="px-3 py-2.5 font-mono font-bold text-slate-900">{m.machine_id}</td>
                    <td className="px-3 py-2.5"><StatusBadge status={m.status} /></td>
                    <td className="px-3 py-2.5 font-mono font-semibold tabular-nums text-slate-900">{m.health_score}%</td>
                    <td className="px-3 py-2.5 font-mono tabular-nums text-slate-600">{m.vibration_mms} mm/s</td>
                    <td className="px-3 py-2.5 text-right">
                      <button
                        onClick={() => onSelectMachine(m)}
                        className="px-2 py-0.5 text-[11px] font-semibold text-emerald-700 hover:text-emerald-900 bg-emerald-50 rounded"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Table 2: Recent Production Records */}
        <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900">Recent Production Records</h2>
            <span className="text-xs text-slate-500 font-mono">{filteredProduction.length} Shifts</span>
          </div>
          <div className="overflow-x-auto max-h-64">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 sticky top-0">
                <tr>
                  <th className="px-3 py-2 font-semibold">Date/Shift</th>
                  <th className="px-3 py-2 font-semibold">Machine</th>
                  <th className="px-3 py-2 font-semibold">Target</th>
                  <th className="px-3 py-2 font-semibold">Actual</th>
                  <th className="px-3 py-2 font-semibold">Defects</th>
                  <th className="px-3 py-2 font-semibold">Operator</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredProduction.slice(0, 6).map(p => (
                  <tr key={p.id} className="hover:bg-slate-50">
                    <td className="px-3 py-2 text-slate-700">
                      <span className="font-mono">{p.timestamp.split('T')[0]}</span>
                      <span className="text-slate-400 ml-1">({p.shift})</span>
                    </td>
                    <td className="px-3 py-2 font-mono text-slate-900">{p.machine_id}</td>
                    <td className="px-3 py-2 font-mono tabular-nums text-slate-500">{p.target_units}</td>
                    <td className="px-3 py-2 font-mono tabular-nums font-bold text-slate-900">{p.actual_units}</td>
                    <td className="px-3 py-2 font-mono tabular-nums text-amber-700">{p.defective_units}</td>
                    <td className="px-3 py-2 text-slate-600">{p.operator}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Table 3: Active Incidents */}
        <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900">Active Floor Incidents</h2>
            <span className="text-xs text-slate-500 font-mono">{filteredIncidents.length} Records</span>
          </div>
          <div className="overflow-x-auto max-h-64">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 sticky top-0">
                <tr>
                  <th className="px-3 py-2 font-semibold">ID</th>
                  <th className="px-3 py-2 font-semibold">Machine</th>
                  <th className="px-3 py-2 font-semibold">Severity</th>
                  <th className="px-3 py-2 font-semibold">Status</th>
                  <th className="px-3 py-2 font-semibold">Title</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredIncidents.slice(0, 5).map(inc => (
                  <tr key={inc.id} className="hover:bg-slate-50">
                    <td className="px-3 py-2.5 font-mono text-slate-900">{inc.incident_id}</td>
                    <td className="px-3 py-2.5 font-mono text-slate-700">{inc.machine_id}</td>
                    <td className="px-3 py-2.5"><SeverityBadge severity={inc.severity} /></td>
                    <td className="px-3 py-2.5 font-medium text-slate-700">{inc.status}</td>
                    <td className="px-3 py-2.5 text-slate-800 truncate max-w-[180px]">{inc.title}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Table 4: Pending Work Orders */}
        <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900">Pending & In-Progress Work Orders</h2>
            <span className="text-xs text-slate-500 font-mono">{filteredWorkOrders.length} Records</span>
          </div>
          <div className="overflow-x-auto max-h-64">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 sticky top-0">
                <tr>
                  <th className="px-3 py-2 font-semibold">Work Order</th>
                  <th className="px-3 py-2 font-semibold">Machine</th>
                  <th className="px-3 py-2 font-semibold">Priority</th>
                  <th className="px-3 py-2 font-semibold">Assigned</th>
                  <th className="px-3 py-2 font-semibold">Due</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredWorkOrders.slice(0, 5).map(wo => (
                  <tr key={wo.id} className="hover:bg-slate-50">
                    <td className="px-3 py-2.5 font-mono text-slate-900">{wo.work_order_id}</td>
                    <td className="px-3 py-2.5 font-mono text-slate-700">{wo.machine_id}</td>
                    <td className="px-3 py-2.5"><PriorityBadge priority={wo.priority} /></td>
                    <td className="px-3 py-2.5 text-slate-700">{wo.assigned_to}</td>
                    <td className="px-3 py-2.5 font-mono text-slate-500">{wo.due_date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
