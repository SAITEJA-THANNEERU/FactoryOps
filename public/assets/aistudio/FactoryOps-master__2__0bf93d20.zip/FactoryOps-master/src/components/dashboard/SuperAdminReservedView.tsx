import React from 'react';
import { Shield, Clock, ExternalLink } from 'lucide-react';
import { useRouter } from '../../contexts/RouterContext.tsx';

export const SuperAdminReservedView: React.FC = () => {
  const { navigate } = useRouter();

  return (
    <div className="py-6 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Super Admin Platform Console
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Global Multi-Tenant Administration & Platform Governance
          </p>
        </div>
        <button
          onClick={() => navigate('/super-admin/overview')}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-purple-700 hover:bg-purple-800 text-white text-xs font-semibold rounded-md shadow-2xs transition-colors"
        >
          <span>Multi-Plant System View</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Clean Empty Dashboard Content Area */}
      <div className="bg-white border border-slate-200 rounded-xl p-12 text-center shadow-2xs max-w-2xl mx-auto my-12">
        <div className="w-12 h-12 rounded-xl bg-purple-50 border border-purple-200 text-purple-700 flex items-center justify-center mx-auto mb-4">
          <Shield className="w-6 h-6" />
        </div>
        <h2 className="text-lg font-semibold text-slate-900 mb-2">
          Dashboard Reserved for Future Expansion
        </h2>
        <p className="text-sm text-slate-600 max-w-md mx-auto leading-relaxed mb-6">
          The Super Admin operational view is currently reserved for future multi-organization governance, enterprise directory integration, and global tenant telemetry releases.
        </p>
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-50 border border-slate-200 text-xs text-slate-500">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span>Status: Foundation Reserved • Role Access Control Active</span>
        </div>
      </div>
    </div>
  );
};
