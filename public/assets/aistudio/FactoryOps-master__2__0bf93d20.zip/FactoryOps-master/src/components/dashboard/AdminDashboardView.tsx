import React, { useMemo } from 'react';
import type { Machine, ProductionRecord, Incident, WorkOrder, MaintenanceRecord, FactoryKPIs } from '../../types/index.ts';
import { useFilters } from '../../contexts/FilterContext.tsx';
import { GlobalDashboardFilters } from './GlobalDashboardFilters.tsx';
import { StatusBadge } from '../StatusBadge.tsx';
import { SeverityBadge } from '../SeverityBadge.tsx';
import { PriorityBadge } from '../PriorityBadge.tsx';
import {
  Cpu,
  TrendingUp,
  AlertTriangle,
  ClipboardList,
  Wrench,
  Gauge,
  Activity,
  Plus,
  ArrowUpRight,
  ShieldAlert,
  Calendar,
  Layers,
  Thermometer,
  Zap
} from 'lucide-react';
import {
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface AdminDashboardViewProps {
  machines: Machine[];
  production: ProductionRecord[];
  incidents: Incident[];
  workOrders: WorkOrder[];
  maintenance: MaintenanceRecord[];
  kpis: FactoryKPIs | null;
  onSelectMachine: (machine: Machine) => void;
  onOpenIncidentModal: () => void;
  onOpenWorkOrderModal: () => void;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  machines,
  production,
  incidents,
  workOrders,
  maintenance,
  kpis,
  onSelectMachine,
  onOpenIncidentModal,
  onOpenWorkOrderModal
}) => {
  const {
    selectedLine,
    selectedShift,
    selectedStatus,
    selectedMachine,
    selectedPriority,
    timeRange
  } = useFilters();

  // 1. Filtered Machines
  const filteredMachines = useMemo(() => {
    return machines.filter(m => {
      if (selectedLine !== 'all' && m.line !== selectedLine) return false;
      if (selectedStatus !== 'all' && m.status !== selectedStatus) return false;
      if (selectedMachine !== 'all' && m.machine_id !== selectedMachine) return false;
      return true;
    });
  }, [machines, selectedLine, selectedStatus, selectedMachine]);

  // 2. Filtered Production records based on date range, line, machine, shift
  const filteredProduction = useMemo(() => {
    const machineIds = new Set(filteredMachines.map(m => m.machine_id));

    // Determine cutoff date for timeRange
    const now = new Date();
    let daysCutoff = 14;
    if (timeRange === 'today') daysCutoff = 1;
    else if (timeRange === '7d') daysCutoff = 7;
    else if (timeRange === '14d') daysCutoff = 14;
    else if (timeRange === 'all') daysCutoff = 365;

    const cutoffTime = now.getTime() - daysCutoff * 86400000;

    return production.filter(p => {
      if (!machineIds.has(p.machine_id)) return false;
      if (selectedShift !== 'all' && p.shift !== selectedShift) return false;
      if (selectedMachine !== 'all' && p.machine_id !== selectedMachine) return false;

      const recordTime = new Date(p.timestamp).getTime();
      return recordTime >= cutoffTime;
    });
  }, [production, filteredMachines, timeRange, selectedShift, selectedMachine]);

  // 3. Filtered Incidents
  const filteredIncidents = useMemo(() => {
    const machineIds = new Set(filteredMachines.map(m => m.machine_id));
    return incidents.filter(inc => {
      if (!machineIds.has(inc.machine_id)) return false;
      if (selectedMachine !== 'all' && inc.machine_id !== selectedMachine) return false;
      return true;
    });
  }, [incidents, filteredMachines, selectedMachine]);

  // 4. Filtered Work Orders
  const filteredWorkOrders = useMemo(() => {
    const machineIds = new Set(filteredMachines.map(m => m.machine_id));
    return workOrders.filter(wo => {
      if (!machineIds.has(wo.machine_id)) return false;
      if (selectedMachine !== 'all' && wo.machine_id !== selectedMachine) return false;
      if (selectedPriority !== 'all' && wo.priority !== selectedPriority) return false;
      return true;
    });
  }, [workOrders, filteredMachines, selectedMachine, selectedPriority]);

  // 5. Dynamic KPI Calculations
  const totalMachinesCount = filteredMachines.length;
  const activeMachinesCount = filteredMachines.filter(m => m.status === 'running').length;

  const totalProductionUnits = filteredProduction.reduce((acc, p) => acc + p.actual_units, 0);
  const totalPlannedUnits = filteredProduction.reduce((acc, p) => acc + p.target_units, 0);
  const totalDefectsCount = filteredProduction.reduce((acc, p) => acc + p.defective_units, 0);

  const activeIncidentsCount = filteredIncidents.filter(i => i.status === 'Open' || i.status === 'Investigating').length;
  const openWorkOrdersCount = filteredWorkOrders.filter(w => w.status === 'Pending' || w.status === 'In Progress').length;

  const avgOee = filteredMachines.length > 0
    ? Math.round((filteredMachines.reduce((acc, m) => acc + (m.oee || 0), 0) / filteredMachines.length) * 10) / 10
    : (kpis?.oee || 0);

  // 6. Visualizations Datasets

  // V1: Production Performance (Planned vs Actual over time)
  const productionPerformanceData = useMemo(() => {
    const dateMap: Record<string, { date: string; planned: number; actual: number }> = {};
    filteredProduction.forEach(p => {
      const dateKey = p.timestamp.split('T')[0].substring(5); // MM-DD
      if (!dateMap[dateKey]) {
        dateMap[dateKey] = { date: dateKey, planned: 0, actual: 0 };
      }
      dateMap[dateKey].planned += p.target_units;
      dateMap[dateKey].actual += p.actual_units;
    });
    return Object.values(dateMap).slice(-7);
  }, [filteredProduction]);

  // V2: Machine Status Breakdown
  const statusBreakdownData = useMemo(() => {
    const counts = { running: 0, warning: 0, maintenance: 0, offline: 0 };
    filteredMachines.forEach(m => {
      if (counts[m.status] !== undefined) {
        counts[m.status]++;
      }
    });
    return [
      { name: 'Running', count: counts.running, color: '#059669' },
      { name: 'Warning', count: counts.warning, color: '#d97706' },
      { name: 'Maintenance', count: counts.maintenance, color: '#dc2626' },
      { name: 'Offline', count: counts.offline, color: '#64748b' }
    ].filter(item => item.count > 0);
  }, [filteredMachines]);

  // V3: Production Volume and Defect Trends
  const trendData = useMemo(() => {
    const dateMap: Record<string, { date: string; production: number; defects: number }> = {};
    filteredProduction.forEach(p => {
      const dateKey = p.timestamp.split('T')[0].substring(5);
      if (!dateMap[dateKey]) {
        dateMap[dateKey] = { date: dateKey, production: 0, defects: 0 };
      }
      dateMap[dateKey].production += p.actual_units;
      dateMap[dateKey].defects += p.defective_units;
    });
    return Object.values(dateMap).slice(-10);
  }, [filteredProduction]);

  // V4: Incidents by Severity
  const incidentsBySeverityData = useMemo(() => {
    const counts: Record<string, number> = { Critical: 0, High: 0, Medium: 0, Low: 0 };
    filteredIncidents.forEach(inc => {
      if (counts[inc.severity] !== undefined) {
        counts[inc.severity]++;
      }
    });
    return [
      { severity: 'Critical', count: counts.Critical, fill: '#dc2626' },
      { severity: 'High', count: counts.High, fill: '#ea580c' },
      { severity: 'Medium', count: counts.Medium, fill: '#d97706' },
      { severity: 'Low', count: counts.Low, fill: '#059669' }
    ];
  }, [filteredIncidents]);

  // V5: Work Orders by Status
  const workOrdersByStatusData = useMemo(() => {
    const counts: Record<string, number> = { Pending: 0, 'In Progress': 0, Completed: 0 };
    filteredWorkOrders.forEach(wo => {
      if (counts[wo.status] !== undefined) {
        counts[wo.status]++;
      }
    });
    return [
      { status: 'Pending', count: counts.Pending, fill: '#d97706' },
      { status: 'In Progress', count: counts['In Progress'], fill: '#2563eb' },
      { status: 'Completed', count: counts.Completed, fill: '#059669' }
    ];
  }, [filteredWorkOrders]);

  // V6: Machine Health Distribution
  const machineHealthList = useMemo(() => {
    return [...filteredMachines]
      .sort((a, b) => a.health_score - b.health_score)
      .slice(0, 6);
  }, [filteredMachines]);

  // V7: Maintenance Overview
  const upcomingMaintenance = useMemo(() => {
    return maintenance.slice(0, 4);
  }, [maintenance]);

  return (
    <div className="space-y-6">
      {/* Title & Quick Actions */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Plant Operational Overview
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Holistic factory command, machine telemetry, production output & asset maintenance
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenIncidentModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 text-xs font-semibold rounded-md shadow-2xs transition-colors"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
            <span>Report Incident</span>
          </button>
          <button
            onClick={onOpenWorkOrderModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-md shadow-2xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-emerald-400" />
            <span>New Work Order</span>
          </button>
        </div>
      </div>

      {/* Global Interactive Filters */}
      <GlobalDashboardFilters
        machines={machines}
        showStatusFilter={true}
        showPriorityFilter={true}
      />

      {/* 7 KPI Cards (Strictly Grounded in Dataset) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
        {/* KPI 1: Total Machines */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1.5">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Total Units</span>
            <Cpu className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-900 tabular-nums">
            {totalMachinesCount}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">Assigned equipment</p>
        </div>

        {/* KPI 2: Active Machines */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1.5">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-700">Active Units</span>
            <Zap className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-bold font-mono text-emerald-700 tabular-nums">
            {activeMachinesCount}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">
            {totalMachinesCount > 0 ? `${Math.round((activeMachinesCount / totalMachinesCount) * 100)}% online` : '0%'}
          </p>
        </div>

        {/* KPI 3: Total Production */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1.5">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-blue-700">Production</span>
            <TrendingUp className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-900 tabular-nums">
            {totalProductionUnits.toLocaleString()}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">
            {totalPlannedUnits > 0 ? `${Math.round((totalProductionUnits / totalPlannedUnits) * 100)}% target` : 'units'}
          </p>
        </div>

        {/* KPI 4: Total Defects */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1.5">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-amber-700">Defects</span>
            <AlertTriangle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-900 tabular-nums">
            {totalDefectsCount}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">
            {totalProductionUnits > 0
              ? `${((totalDefectsCount / (totalProductionUnits + totalDefectsCount)) * 100).toFixed(1)}% rate`
              : '0.0%'}
          </p>
        </div>

        {/* KPI 5: Active Incidents */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1.5">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-rose-700">Incidents</span>
            <ShieldAlert className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-xl font-bold font-mono text-rose-700 tabular-nums">
            {activeIncidentsCount}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">Open & investigating</p>
        </div>

        {/* KPI 6: Open Work Orders */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1.5">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-purple-700">Work Orders</span>
            <ClipboardList className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-900 tabular-nums">
            {openWorkOrdersCount}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">Pending / In Progress</p>
        </div>

        {/* KPI 7: OEE */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1.5">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-700">Avg OEE</span>
            <Gauge className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-bold font-mono text-emerald-700 tabular-nums">
            {avgOee}%
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">Plant effectiveness</p>
        </div>
      </div>

      {/* Visualizations Grid: Power BI Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Visual 1: Production Performance (Planned vs Actual over time) */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Production Performance: Planned vs Actual</h2>
              <p className="text-xs text-slate-500">Grouped unit comparison across recent operating days</p>
            </div>
            <span className="text-xs font-mono text-slate-400">Units</span>
          </div>
          <div className="h-64">
            {productionPerformanceData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={productionPerformanceData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                    itemStyle={{ color: '#fff' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                  <Bar dataKey="planned" name="Planned Target" fill="#94a3b8" radius={[2, 2, 0, 0]} />
                  <Bar dataKey="actual" name="Actual Units" fill="#059669" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                No production records match the selected filters.
              </div>
            )}
          </div>
        </div>

        {/* Visual 2: Machine Status Overview */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Machine Status Overview</h2>
              <p className="text-xs text-slate-500">Distribution of operational machine states</p>
            </div>
          </div>
          <div className="h-64 flex flex-col items-center justify-center">
            {statusBreakdownData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusBreakdownData}
                    dataKey="count"
                    nameKey="name"
                    cx="50%"
                    cy="45%"
                    innerRadius={50}
                    outerRadius={75}
                    paddingAngle={3}
                  >
                    {statusBreakdownData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-xs text-slate-400">No machine status data available.</div>
            )}
          </div>
        </div>

        {/* Visual 3: Production Volume and Defect Trends */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Production Volume & Defect Rate Trends</h2>
              <p className="text-xs text-slate-500">Yield continuity vs defect volume across shift timelines</p>
            </div>
            <span className="text-xs font-mono text-slate-400">Units</span>
          </div>
          <div className="h-60">
            {trendData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <defs>
                    <linearGradient id="adminProdColor" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0284c7" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="#0284c7" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="adminDefectColor" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                  <Area type="monotone" dataKey="production" name="Production Output" stroke="#0284c7" fillOpacity={1} fill="url(#adminProdColor)" />
                  <Area type="monotone" dataKey="defects" name="Defective Units" stroke="#ef4444" fillOpacity={1} fill="url(#adminDefectColor)" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-400">
                No trend data for selected criteria.
              </div>
            )}
          </div>
        </div>

        {/* Visual 4 & 5: Severity & Work Orders distribution */}
        <div className="space-y-6">
          {/* Incidents by Severity */}
          <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
            <h2 className="text-sm font-bold text-slate-900 mb-1">Incidents by Severity</h2>
            <p className="text-xs text-slate-500 mb-2">Active and logged incidents grouped by risk tier</p>
            <div className="h-28">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={incidentsBySeverityData} layout="vertical" margin={{ top: 0, right: 10, left: 10, bottom: 0 }}>
                  <XAxis type="number" hide />
                  <YAxis dataKey="severity" type="category" tick={{ fontSize: 11, fill: '#475569' }} axisLine={false} tickLine={false} width={60} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                  />
                  <Bar dataKey="count" name="Incidents" radius={[0, 4, 4, 0]}>
                    {incidentsBySeverityData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Work Orders by Status */}
          <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
            <h2 className="text-sm font-bold text-slate-900 mb-1">Work Orders by Status</h2>
            <p className="text-xs text-slate-500 mb-2">Maintenance execution queue breakdown</p>
            <div className="h-28">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={workOrdersByStatusData} layout="vertical" margin={{ top: 0, right: 10, left: 10, bottom: 0 }}>
                  <XAxis type="number" hide />
                  <YAxis dataKey="status" type="category" tick={{ fontSize: 11, fill: '#475569' }} axisLine={false} tickLine={false} width={75} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                  />
                  <Bar dataKey="count" name="Work Orders" radius={[0, 4, 4, 0]}>
                    {workOrdersByStatusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>

      {/* Visual 6 & 7: Machine Health & Maintenance Overview Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Visual 6: Machine Health & Telemetry Overview */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Machine Health & Diagnostics Telemetry</h2>
              <p className="text-xs text-slate-500">Real-time vibration, thermal and health ratings</p>
            </div>
            <Gauge className="w-4 h-4 text-emerald-600" />
          </div>

          <div className="space-y-2.5">
            {machineHealthList.map(m => (
              <div
                key={m.id}
                onClick={() => onSelectMachine(m)}
                className="p-2.5 rounded bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2.5">
                  <StatusBadge status={m.status} />
                  <div>
                    <span className="font-bold text-slate-900 font-mono">{m.machine_id}</span>
                    <span className="text-slate-500 ml-1.5">{m.name}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-slate-600">
                  <div className="flex items-center gap-1 font-mono tabular-nums">
                    <Thermometer className="w-3.5 h-3.5 text-slate-400" />
                    <span>{m.temperature_c}°C</span>
                  </div>
                  <div className="flex items-center gap-1 font-mono tabular-nums">
                    <Activity className="w-3.5 h-3.5 text-slate-400" />
                    <span>{m.vibration_mms} mm/s</span>
                  </div>
                  <div className="font-bold font-mono text-slate-900 tabular-nums w-12 text-right">
                    {m.health_score}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Visual 7: Upcoming & Outstanding Maintenance Overview */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Maintenance & Servicing Schedules</h2>
              <p className="text-xs text-slate-500">Upcoming preventative and corrective activities</p>
            </div>
            <Wrench className="w-4 h-4 text-amber-600" />
          </div>

          <div className="space-y-2.5">
            {upcomingMaintenance.map(mnt => (
              <div key={mnt.id} className="p-2.5 rounded bg-slate-50 border border-slate-200 text-xs flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 font-mono">{mnt.machine_id}</span>
                    <span className="text-[11px] font-semibold px-1.5 py-0.5 rounded bg-slate-200 text-slate-700">
                      {mnt.type}
                    </span>
                    <span className="text-[11px] text-slate-500">{mnt.status}</span>
                  </div>
                  <p className="text-slate-600 mt-1 line-clamp-1">{mnt.description}</p>
                </div>

                <div className="text-right shrink-0 ml-3">
                  <div className="font-mono text-slate-900 font-semibold">{mnt.scheduled_date}</div>
                  <div className="text-[10px] text-slate-500">{mnt.technician}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Operational Tables (Recent Incidents, Recent Work Orders, Machine Overview) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Table 1: Recent Incidents */}
        <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900">Recent Plant Incidents</h2>
            <span className="text-xs text-slate-500 font-mono">{filteredIncidents.length} Records</span>
          </div>
          <div className="overflow-x-auto max-h-72">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 sticky top-0">
                <tr>
                  <th className="px-3 py-2 font-semibold">Incident ID</th>
                  <th className="px-3 py-2 font-semibold">Machine</th>
                  <th className="px-3 py-2 font-semibold">Severity</th>
                  <th className="px-3 py-2 font-semibold">Status</th>
                  <th className="px-3 py-2 font-semibold">Reported</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredIncidents.slice(0, 5).map(inc => (
                  <tr key={inc.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-3 py-2.5 font-mono font-medium text-slate-900">{inc.incident_id}</td>
                    <td className="px-3 py-2.5 font-mono text-slate-700">{inc.machine_id}</td>
                    <td className="px-3 py-2.5"><SeverityBadge severity={inc.severity} /></td>
                    <td className="px-3 py-2.5"><span className="text-slate-600 font-medium">{inc.status}</span></td>
                    <td className="px-3 py-2.5 text-slate-500">{inc.reported_at ? inc.reported_at.split('T')[0] : 'N/A'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Table 2: Recent Work Orders */}
        <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900">Recent Work Orders</h2>
            <span className="text-xs text-slate-500 font-mono">{filteredWorkOrders.length} Records</span>
          </div>
          <div className="overflow-x-auto max-h-72">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 sticky top-0">
                <tr>
                  <th className="px-3 py-2 font-semibold">Work Order</th>
                  <th className="px-3 py-2 font-semibold">Machine</th>
                  <th className="px-3 py-2 font-semibold">Priority</th>
                  <th className="px-3 py-2 font-semibold">Assigned To</th>
                  <th className="px-3 py-2 font-semibold">Due Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredWorkOrders.slice(0, 5).map(wo => (
                  <tr key={wo.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-3 py-2.5 font-mono font-medium text-slate-900">{wo.work_order_id}</td>
                    <td className="px-3 py-2.5 font-mono text-slate-700">{wo.machine_id}</td>
                    <td className="px-3 py-2.5"><PriorityBadge priority={wo.priority} /></td>
                    <td className="px-3 py-2.5 text-slate-600">{wo.assigned_to}</td>
                    <td className="px-3 py-2.5 font-mono text-slate-500">{wo.due_date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Table 3: Complete Machine Overview */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
        <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Factory Equipment Fleet Overview</h2>
            <p className="text-xs text-slate-500">Status, telemetry diagnostics & efficiency ratings</p>
          </div>
          <span className="text-xs text-slate-500 font-mono">{filteredMachines.length} Units Listed</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
              <tr>
                <th className="px-3 py-2.5 font-semibold">Machine ID</th>
                <th className="px-3 py-2.5 font-semibold">Machine Name</th>
                <th className="px-3 py-2.5 font-semibold">Line</th>
                <th className="px-3 py-2.5 font-semibold">Status</th>
                <th className="px-3 py-2.5 font-semibold">Health Score</th>
                <th className="px-3 py-2.5 font-semibold">Temperature</th>
                <th className="px-3 py-2.5 font-semibold">OEE</th>
                <th className="px-3 py-2.5 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredMachines.map(m => (
                <tr key={m.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="px-3 py-2.5 font-mono font-bold text-slate-900">{m.machine_id}</td>
                  <td className="px-3 py-2.5 text-slate-800 font-medium">{m.name}</td>
                  <td className="px-3 py-2.5 text-slate-600">{m.line}</td>
                  <td className="px-3 py-2.5"><StatusBadge status={m.status} /></td>
                  <td className="px-3 py-2.5 font-mono tabular-nums font-semibold text-slate-900">{m.health_score}%</td>
                  <td className="px-3 py-2.5 font-mono tabular-nums text-slate-700">{m.temperature_c}°C</td>
                  <td className="px-3 py-2.5 font-mono tabular-nums text-emerald-700 font-semibold">{m.oee}%</td>
                  <td className="px-3 py-2.5 text-right">
                    <button
                      onClick={() => onSelectMachine(m)}
                      className="px-2 py-1 text-[11px] font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded transition-colors inline-flex items-center gap-1"
                    >
                      <span>Inspect</span>
                      <ArrowUpRight className="w-3 h-3 text-slate-400" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
