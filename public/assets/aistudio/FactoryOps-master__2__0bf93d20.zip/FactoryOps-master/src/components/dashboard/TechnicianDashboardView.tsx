import React, { useState, useMemo } from 'react';
import type { Machine, WorkOrder, MaintenanceRecord, Incident, SOP } from '../../types/index.ts';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { useData } from '../../contexts/DataContext.tsx';
import { useRouter } from '../../contexts/RouterContext.tsx';
import { StatusBadge } from '../StatusBadge.tsx';
import { PriorityBadge } from '../PriorityBadge.tsx';
import {
  Wrench,
  AlertTriangle,
  Clock,
  CheckCircle2,
  AlertCircle,
  Play,
  RotateCcw,
  BookOpen,
  Cpu,
  Thermometer,
  Activity,
  ArrowUpRight,
  ShieldCheck,
  Calendar
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  Cell
} from 'recharts';

interface TechnicianDashboardViewProps {
  machines: Machine[];
  workOrders: WorkOrder[];
  maintenance: MaintenanceRecord[];
  incidents: Incident[];
  sops: SOP[];
  onSelectMachine: (machine: Machine) => void;
  onOpenWorkOrderModal: () => void;
}

export const TechnicianDashboardView: React.FC<TechnicianDashboardViewProps> = ({
  machines,
  workOrders,
  maintenance,
  incidents,
  sops,
  onSelectMachine,
  onOpenWorkOrderModal
}) => {
  const { user } = useAuth();
  const { updateWorkOrder, refreshData } = useData();
  const { navigate } = useRouter();

  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  // Today's date string YYYY-MM-DD
  const todayStr = new Date().toISOString().split('T')[0];

  // Current technician's name or keywords
  const techIdentifier = user?.name?.toLowerCase() || '';

  // 1. My Assigned Work Orders (Matches user name or "Technician" or all plant orders if unassigned)
  const myAssignedWorkOrders = useMemo(() => {
    return workOrders.filter(wo => {
      const assigned = (wo.assigned_to || '').toLowerCase();
      // Match specific user name or fallback to technician tasks
      return (
        assigned.includes(techIdentifier.split(' ')[0]) ||
        assigned.includes('ramesh') ||
        assigned.includes('tech') ||
        assigned.includes('kishore') ||
        assigned.includes('anil')
      );
    });
  }, [workOrders, techIdentifier]);

  // Fallback to all work orders in plant if myAssigned is empty
  const effectiveWorkOrders = myAssignedWorkOrders.length > 0 ? myAssignedWorkOrders : workOrders;

  // Filtered tasks for view
  const filteredTasks = useMemo(() => {
    return effectiveWorkOrders.filter(wo => {
      if (statusFilter !== 'all' && wo.status !== statusFilter) return false;
      if (priorityFilter !== 'all' && wo.priority !== priorityFilter) return false;
      return true;
    });
  }, [effectiveWorkOrders, statusFilter, priorityFilter]);

  // Overdue Work Orders: due_date < today and not completed
  const overdueTasks = useMemo(() => {
    return effectiveWorkOrders.filter(wo => {
      return wo.status !== 'Completed' && wo.due_date < todayStr;
    });
  }, [effectiveWorkOrders, todayStr]);

  // High Priority tasks
  const highPriorityTasks = useMemo(() => {
    return effectiveWorkOrders.filter(wo => wo.priority === 'High' || wo.priority === 'Critical');
  }, [effectiveWorkOrders]);

  // In Progress tasks
  const inProgressTasks = useMemo(() => {
    return effectiveWorkOrders.filter(wo => wo.status === 'In Progress');
  }, [effectiveWorkOrders]);

  // Completed tasks
  const completedTasks = useMemo(() => {
    return effectiveWorkOrders.filter(wo => wo.status === 'Completed');
  }, [effectiveWorkOrders]);

  // Machines requiring attention (warning, maintenance, or high vibration/temperature)
  const machinesAttention = useMemo(() => {
    return machines.filter(m => m.status !== 'running' || m.health_score < 80 || m.vibration_mms > 3.0 || m.temperature_c > 75);
  }, [machines]);

  // 2. 5 Visualizations

  // V1: Work Orders by Status
  const statusData = useMemo(() => {
    const counts: Record<string, number> = { Pending: 0, 'In Progress': 0, Completed: 0 };
    effectiveWorkOrders.forEach(w => {
      if (counts[w.status] !== undefined) counts[w.status]++;
    });
    return [
      { status: 'Pending', count: counts.Pending, fill: '#f59e0b' },
      { status: 'In Progress', count: counts['In Progress'], fill: '#2563eb' },
      { status: 'Completed', count: counts.Completed, fill: '#059669' }
    ];
  }, [effectiveWorkOrders]);

  // V2: Work Orders by Priority
  const priorityData = useMemo(() => {
    const counts = { Critical: 0, High: 0, Medium: 0, Low: 0 };
    effectiveWorkOrders.forEach(w => {
      if (counts[w.priority] !== undefined) counts[w.priority]++;
    });
    return [
      { priority: 'Critical', count: counts.Critical, fill: '#dc2626' },
      { priority: 'High', count: counts.High, fill: '#ea580c' },
      { priority: 'Medium', count: counts.Medium, fill: '#d97706' },
      { priority: 'Low', count: counts.Low, fill: '#10b981' }
    ];
  }, [effectiveWorkOrders]);

  // V3: Maintenance Activity Over Time (Scheduled vs Completed)
  const maintenanceActivityData = useMemo(() => {
    const dateMap: Record<string, { date: string; scheduled: number; completed: number }> = {};
    maintenance.forEach(mnt => {
      const d = mnt.scheduled_date ? mnt.scheduled_date.substring(5) : '10-01';
      if (!dateMap[d]) dateMap[d] = { date: d, scheduled: 0, completed: 0 };
      if (mnt.status === 'Completed') {
        dateMap[d].completed++;
      } else {
        dateMap[d].scheduled++;
      }
    });
    return Object.values(dateMap).slice(-7);
  }, [maintenance]);

  // V4: Downtime by Machine
  const downtimeByMachineData = useMemo(() => {
    const map: Record<string, number> = {};
    maintenance.forEach(mnt => {
      map[mnt.machine_id] = (map[mnt.machine_id] || 0) + mnt.downtime_hours;
    });
    return Object.entries(map)
      .map(([machine, hours]) => ({ machine, hours }))
      .sort((a, b) => b.hours - a.hours)
      .slice(0, 6);
  }, [maintenance]);

  // Handle Quick Status Update for Work Order
  const handleQuickStatusChange = async (woId: string, newStatus: 'Pending' | 'In Progress' | 'Completed') => {
    setUpdatingId(woId);
    try {
      await updateWorkOrder(woId, {
        status: newStatus,
        completed_at: newStatus === 'Completed' ? new Date().toISOString() : undefined
      });
      await refreshData();
    } catch (err) {
      console.error('Failed to update work order', err);
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Quick Actions */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Technician Maintenance Console
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Assigned tasks, equipment troubleshooting, sensor telemetry diagnostics & repair logs
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate('/sops')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-md transition-colors"
          >
            <BookOpen className="w-3.5 h-3.5 text-slate-500" />
            <span>Operating SOPs</span>
          </button>
          <button
            onClick={onOpenWorkOrderModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-md shadow-2xs transition-colors"
          >
            <Wrench className="w-3.5 h-3.5 text-amber-400" />
            <span>Create Maintenance Task</span>
          </button>
        </div>
      </div>

      {/* Filter strip for technician */}
      <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-2xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-700">Filter Tasks:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded px-2.5 py-1 text-slate-800 focus:outline-hidden font-medium"
          >
            <option value="all">All Task Statuses</option>
            <option value="Pending">Pending</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
          </select>
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded px-2.5 py-1 text-slate-800 focus:outline-hidden font-medium"
          >
            <option value="all">All Priorities</option>
            <option value="Critical">Critical</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>

        <div className="text-slate-500 text-[11px] font-mono">
          Showing {filteredTasks.length} assigned task{filteredTasks.length === 1 ? '' : 's'}
        </div>
      </div>

      {/* 6 KPI Cards (Technician Requirements) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* KPI 1: Assigned Work Orders */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Assigned Tasks</span>
            <Wrench className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-900 tabular-nums">
            {effectiveWorkOrders.length}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">Assigned to team</p>
        </div>

        {/* KPI 2: High-Priority Work Orders */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-rose-700">High Priority</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-xl font-bold font-mono text-rose-700 tabular-nums">
            {highPriorityTasks.length}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">Critical & High</p>
        </div>

        {/* KPI 3: In-Progress Work Orders */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-blue-700">In Progress</span>
            <Play className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-xl font-bold font-mono text-blue-700 tabular-nums">
            {inProgressTasks.length}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">Active servicing</p>
        </div>

        {/* KPI 4: Overdue Work Orders */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-amber-700">Overdue</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl font-bold font-mono text-amber-700 tabular-nums">
            {overdueTasks.length}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">Past due target</p>
        </div>

        {/* KPI 5: Completed Work Orders */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-700">Completed</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-bold font-mono text-emerald-700 tabular-nums">
            {completedTasks.length}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">Verified resolved</p>
        </div>

        {/* KPI 6: Machines Requiring Attention */}
        <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-700">Attention Req.</span>
            <AlertCircle className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-xl font-bold font-mono text-slate-900 tabular-nums">
            {machinesAttention.length}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">Units with anomalies</p>
        </div>
      </div>

      {/* Visualizations Grid (5 Technician Visuals) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* V1: Work Orders by Status */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Work Orders by Status</h2>
          <p className="text-xs text-slate-500 mb-2">My queue progress breakdown</p>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={statusData} layout="vertical" margin={{ top: 5, right: 15, left: 15, bottom: 0 }}>
                <XAxis type="number" hide />
                <YAxis dataKey="status" type="category" tick={{ fontSize: 11, fill: '#475569' }} axisLine={false} tickLine={false} width={75} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                />
                <Bar dataKey="count" name="Work Orders" radius={[0, 4, 4, 0]}>
                  {statusData.map((entry, index) => (
                    <Cell key={`status-cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* V2: Work Orders by Priority */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Tasks by Priority</h2>
          <p className="text-xs text-slate-500 mb-2">Urgency classification</p>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={priorityData} layout="vertical" margin={{ top: 5, right: 15, left: 10, bottom: 0 }}>
                <XAxis type="number" hide />
                <YAxis dataKey="priority" type="category" tick={{ fontSize: 11, fill: '#475569' }} axisLine={false} tickLine={false} width={60} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                />
                <Bar dataKey="count" name="Tasks" radius={[0, 4, 4, 0]}>
                  {priorityData.map((entry, index) => (
                    <Cell key={`prio-cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* V3: Maintenance Activity Timeline */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Maintenance Activity</h2>
          <p className="text-xs text-slate-500 mb-2">Scheduled vs completed services</p>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={maintenanceActivityData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '10px' }} />
                <Bar dataKey="scheduled" name="Scheduled" fill="#94a3b8" radius={[2, 2, 0, 0]} />
                <Bar dataKey="completed" name="Completed" fill="#059669" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* V5: Downtime by Machine */}
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Downtime by Equipment</h2>
          <p className="text-xs text-slate-500 mb-2">Top equipment service outages</p>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={downtimeByMachineData} layout="vertical" margin={{ top: 5, right: 15, left: 15, bottom: 0 }}>
                <XAxis type="number" hide />
                <YAxis dataKey="machine" type="category" tick={{ fontSize: 10, fill: '#64748b' }} axisLine={false} tickLine={false} width={65} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '0.375rem', color: '#fff', fontSize: '12px' }}
                  formatter={(val: any) => [`${val} hrs`, 'Downtime']}
                />
                <Bar dataKey="hours" name="Hours" fill="#ef4444" radius={[0, 3, 3, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* V4: Machine Health & Live Diagnostics Telemetry Cards */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-2xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-sm font-bold text-slate-900">Machine Health & Diagnostics Telemetry</h2>
            <p className="text-xs text-slate-500">Live vibration, temperature, speed & operational health status</p>
          </div>
          <span className="text-xs font-mono text-slate-400">{machines.length} Equipment Monitored</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {machines.slice(0, 8).map(m => {
            const isAbnormal = m.vibration_mms > 3.0 || m.temperature_c > 75 || m.status !== 'running';
            return (
              <div
                key={m.id}
                onClick={() => onSelectMachine(m)}
                className={`p-3 rounded-lg border transition-all cursor-pointer ${
                  isAbnormal ? 'bg-amber-50/50 border-amber-200 hover:border-amber-300' : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono font-bold text-xs text-slate-900">{m.machine_id}</span>
                  <StatusBadge status={m.status} />
                </div>
                <div className="text-xs text-slate-600 font-medium truncate mb-2">{m.name}</div>
                <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-slate-200/60 font-mono tabular-nums">
                  <div className="flex items-center gap-1 text-slate-600">
                    <Thermometer className="w-3 h-3 text-slate-400" />
                    <span>{m.temperature_c}°C</span>
                  </div>
                  <div className="flex items-center gap-1 text-slate-600">
                    <Activity className="w-3 h-3 text-slate-400" />
                    <span>{m.vibration_mms} mm/s</span>
                  </div>
                </div>
                <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-slate-200/60 text-xs">
                  <span className="text-[10px] text-slate-500">Health Rating</span>
                  <span className="font-bold font-mono text-slate-900">{m.health_score}%</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Operational Tables: 5 Technician Tables */}
      <div className="space-y-6">
        {/* Table 1: My Assigned Work Orders (Interactive with Real Status Update Action Buttons!) */}
        <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900">My Assigned Work Orders</h2>
              <p className="text-xs text-slate-500">Execute and update status directly from the console</p>
            </div>
            <span className="text-xs text-slate-500 font-mono">{filteredTasks.length} Tasks</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="px-3 py-2.5 font-semibold">Order ID</th>
                  <th className="px-3 py-2.5 font-semibold">Machine</th>
                  <th className="px-3 py-2.5 font-semibold">Task Title</th>
                  <th className="px-3 py-2.5 font-semibold">Priority</th>
                  <th className="px-3 py-2.5 font-semibold">Status</th>
                  <th className="px-3 py-2.5 font-semibold">Due Date</th>
                  <th className="px-3 py-2.5 font-semibold text-right">Action / Update Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTasks.map(wo => {
                  const isOverdue = wo.status !== 'Completed' && wo.due_date < todayStr;
                  const isUpdating = updatingId === wo.id;

                  return (
                    <tr key={wo.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="px-3 py-2.5 font-mono font-bold text-slate-900">{wo.work_order_id}</td>
                      <td className="px-3 py-2.5 font-mono text-slate-800 font-medium">{wo.machine_id}</td>
                      <td className="px-3 py-2.5 text-slate-800 font-medium max-w-xs truncate">{wo.title}</td>
                      <td className="px-3 py-2.5"><PriorityBadge priority={wo.priority} /></td>
                      <td className="px-3 py-2.5">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                          wo.status === 'Completed' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' :
                          wo.status === 'In Progress' ? 'bg-blue-50 text-blue-700 border border-blue-200' :
                          'bg-amber-50 text-amber-800 border border-amber-200'
                        }`}>
                          {wo.status}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 font-mono">
                        <span className={isOverdue ? 'text-rose-600 font-bold flex items-center gap-1' : 'text-slate-600'}>
                          {isOverdue && <AlertTriangle className="w-3 h-3" />}
                          {wo.due_date}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {wo.status === 'Pending' && (
                            <button
                              disabled={isUpdating}
                              onClick={() => handleQuickStatusChange(wo.id, 'In Progress')}
                              className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-[11px] font-semibold transition-colors flex items-center gap-1"
                            >
                              <Play className="w-3 h-3" />
                              <span>Start Task</span>
                            </button>
                          )}
                          {wo.status === 'In Progress' && (
                            <button
                              disabled={isUpdating}
                              onClick={() => handleQuickStatusChange(wo.id, 'Completed')}
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[11px] font-semibold transition-colors flex items-center gap-1"
                            >
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Mark Complete</span>
                            </button>
                          )}
                          {wo.status === 'Completed' && (
                            <button
                              disabled={isUpdating}
                              onClick={() => handleQuickStatusChange(wo.id, 'In Progress')}
                              className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[11px] font-medium transition-colors flex items-center gap-1"
                              title="Re-open task"
                            >
                              <RotateCcw className="w-3 h-3 text-slate-500" />
                              <span>Re-open</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Table 2: Overdue Tasks Alert Strip */}
        {overdueTasks.length > 0 && (
          <div className="bg-rose-50 border border-rose-200 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-rose-800">
                  Critical Alert: Overdue Maintenance Tasks
                </h3>
              </div>
              <span className="text-xs font-mono font-bold text-rose-700">{overdueTasks.length} Overdue</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
              {overdueTasks.map(t => (
                <div key={t.id} className="p-2.5 bg-white border border-rose-200 rounded flex items-center justify-between">
                  <div>
                    <span className="font-mono font-bold text-slate-900">{t.work_order_id}</span>
                    <span className="text-slate-500 ml-1.5">({t.machine_id})</span>
                    <p className="text-slate-700 mt-0.5 line-clamp-1">{t.title}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-xs font-mono font-bold text-rose-600">{t.due_date}</span>
                    <div className="mt-1">
                      <PriorityBadge priority={t.priority} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 2-Column Split: Upcoming Maintenance & Machines Requiring Attention */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Table 3: Upcoming Maintenance Schedules */}
          <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
            <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">Upcoming Preventive Maintenance</h2>
              <span className="text-xs text-slate-500 font-mono">{maintenance.length} Schedules</span>
            </div>
            <div className="overflow-x-auto max-h-64">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 sticky top-0">
                  <tr>
                    <th className="px-3 py-2 font-semibold">Schedule Date</th>
                    <th className="px-3 py-2 font-semibold">Machine</th>
                    <th className="px-3 py-2 font-semibold">Type</th>
                    <th className="px-3 py-2 font-semibold">Assigned Tech</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {maintenance.slice(0, 6).map(m => (
                    <tr key={m.id} className="hover:bg-slate-50">
                      <td className="px-3 py-2 font-mono text-slate-900 font-medium">{m.scheduled_date}</td>
                      <td className="px-3 py-2 font-mono text-slate-700">{m.machine_id}</td>
                      <td className="px-3 py-2">
                        <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-medium text-[11px]">
                          {m.type}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-slate-600">{m.technician}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Table 4: Machines Requiring Attention */}
          <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
            <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">Machines Requiring Attention</h2>
              <span className="text-xs text-slate-500 font-mono">{machinesAttention.length} Units</span>
            </div>
            <div className="overflow-x-auto max-h-64">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200 sticky top-0">
                  <tr>
                    <th className="px-3 py-2 font-semibold">Machine</th>
                    <th className="px-3 py-2 font-semibold">Status</th>
                    <th className="px-3 py-2 font-semibold">Health Score</th>
                    <th className="px-3 py-2 font-semibold text-right">Inspect</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {machinesAttention.map(m => (
                    <tr key={m.id} className="hover:bg-slate-50">
                      <td className="px-3 py-2.5 font-mono font-bold text-slate-900">{m.machine_id}</td>
                      <td className="px-3 py-2.5"><StatusBadge status={m.status} /></td>
                      <td className="px-3 py-2.5 font-mono font-semibold tabular-nums text-slate-900">{m.health_score}%</td>
                      <td className="px-3 py-2.5 text-right">
                        <button
                          onClick={() => onSelectMachine(m)}
                          className="px-2 py-0.5 text-[11px] font-semibold text-emerald-700 hover:text-emerald-900 bg-emerald-50 rounded"
                        >
                          Diagnostics
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Table 5: Recent Maintenance History */}
        <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-2xs">
          <div className="px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900">Recent Maintenance Log History</h2>
            <span className="text-xs text-slate-500 font-mono">Service Records</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="px-3 py-2.5 font-semibold">Record ID</th>
                  <th className="px-3 py-2.5 font-semibold">Machine</th>
                  <th className="px-3 py-2.5 font-semibold">Type</th>
                  <th className="px-3 py-2.5 font-semibold">Description</th>
                  <th className="px-3 py-2.5 font-semibold">Downtime</th>
                  <th className="px-3 py-2.5 font-semibold">Serviced By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {maintenance.map(mnt => (
                  <tr key={mnt.id} className="hover:bg-slate-50">
                    <td className="px-3 py-2.5 font-mono font-medium text-slate-900">{mnt.id}</td>
                    <td className="px-3 py-2.5 font-mono text-slate-700">{mnt.machine_id}</td>
                    <td className="px-3 py-2.5">
                      <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-medium text-[11px]">
                        {mnt.type}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-slate-700 max-w-sm truncate">{mnt.description}</td>
                    <td className="px-3 py-2.5 font-mono text-slate-800">{mnt.downtime_hours} hrs</td>
                    <td className="px-3 py-2.5 text-slate-600">{mnt.technician}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
