import React from 'react';
import { useRouter } from '../contexts/RouterContext.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import {
  LayoutDashboard,
  Cpu,
  TrendingUp,
  Wrench,
  AlertTriangle,
  ClipboardList,
  CheckCircle2,
  BarChart3,
  BookOpen,
  Activity,
  Settings,
  CalendarCheck
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const { currentPath, navigate } = useRouter();
  const { user } = useAuth();

  const getNavItems = () => {
    switch (user?.role) {
      case 'TECHNICIAN':
      case 'OPERATOR':
        return [
          { path: '/dashboard', label: 'My Dashboard', icon: LayoutDashboard },
          { path: '/work-orders', label: 'My Work Orders', icon: ClipboardList },
          { path: '/machines', label: 'Assigned Machines', icon: Cpu },
          { path: '/maintenance', label: 'Maintenance', icon: Wrench },
          { path: '/incidents', label: 'Incidents', icon: AlertTriangle },
          { path: '/sops', label: 'SOPs', icon: BookOpen }
        ];

      case 'PRODUCTION_PLANNER':
      case 'ANALYST':
        return [
          { path: '/dashboard', label: 'Planning Dashboard', icon: CalendarCheck },
          { path: '/production', label: 'Production', icon: TrendingUp },
          { path: '/analytics', label: 'Production Analysis', icon: BarChart3 },
          { path: '/machines', label: 'Machine Performance', icon: Cpu },
          { path: '/operations', label: 'Downtime Analysis', icon: Activity },
          { path: '/work-orders', label: 'Work Orders', icon: ClipboardList }
        ];

      case 'MANAGER_SUPERVISOR':
      case 'FACTORY_MANAGER':
      case 'SUPERVISOR':
        return [
          { path: '/dashboard', label: 'Overview', icon: LayoutDashboard },
          { path: '/operations', label: 'Operations', icon: Activity },
          { path: '/production', label: 'Production', icon: TrendingUp },
          { path: '/machines', label: 'Machines', icon: Cpu },
          { path: '/incidents', label: 'Incidents', icon: AlertTriangle },
          { path: '/work-orders', label: 'Work Orders', icon: ClipboardList },
          { path: '/quality', label: 'Quality', icon: CheckCircle2 },
          { path: '/sops', label: 'SOPs', icon: BookOpen }
        ];

      case 'SUPER_ADMIN':
        return [
          { path: '/dashboard', label: 'Reserved Dashboard', icon: LayoutDashboard },
          { path: '/super-admin/overview', label: 'Multi-Plant Overview', icon: Activity }
        ];

      case 'ADMIN':
      case 'FACTORY_OWNER':
      default:
        return [
          { path: '/dashboard', label: 'Overview', icon: LayoutDashboard },
          { path: '/operations', label: 'Operations', icon: Activity },
          { path: '/production', label: 'Production', icon: TrendingUp },
          { path: '/machines', label: 'Machines', icon: Cpu },
          { path: '/maintenance', label: 'Maintenance', icon: Wrench },
          { path: '/incidents', label: 'Incidents', icon: AlertTriangle },
          { path: '/work-orders', label: 'Work Orders', icon: ClipboardList },
          { path: '/quality', label: 'Quality', icon: CheckCircle2 },
          { path: '/sops', label: 'SOPs', icon: BookOpen },
          { path: '/data-quality', label: 'Data Quality', icon: Activity },
          { path: '/admin', label: 'Administration', icon: Settings }
        ];
    }
  };

  const factoryNavItems = getNavItems();

  return (
    <nav className="bg-white border-b border-slate-200 sticky top-16 z-30 overflow-x-auto scrollbar-none shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex space-x-1 sm:space-x-2 min-w-max">
          {factoryNavItems.map(item => {
            const Icon = item.icon;
            const isActive = currentPath === item.path || (item.path === '/dashboard' && currentPath === '/');

            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`flex items-center gap-1.5 px-3 py-3 text-xs sm:text-sm font-medium transition-colors border-b-2 ${
                  isActive
                    ? 'border-emerald-600 text-emerald-800 font-semibold bg-emerald-50/50'
                    : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-600' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
