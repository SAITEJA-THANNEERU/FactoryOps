import { createClient, SupabaseClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import { db } from './db.ts';
import type {
  Factory,
  Machine,
  ProductionRecord,
  MaintenanceRecord,
  Incident,
  WorkOrder,
  SOP,
  DataQualityMetric,
  User,
  FactoryKPIs,
  SuperAdminOverview
} from '../src/types/index.ts';

dotenv.config();

const SUPABASE_URL = process.env.SUPABASE_URL || 'https://fnkldnopljxbmsoofhzh.supabase.co';
const SUPABASE_KEY = process.env.SUPABASE_ANON_KEY || 'sb_publishable_uXYNtz2MZIyMVq04x59F1Q_ndA-3Zcw';

export const supabase: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: {
    persistSession: false,
    autoRefreshToken: false
  }
});

let isSupabaseHealthy = false;
let hasCheckedTables = false;
let lastCheckTime = 0;
const CHECK_INTERVAL_MS = 15000; // Recheck every 15s until tables exist

// Check connection and report state
export async function testSupabaseConnection(): Promise<boolean> {
  lastCheckTime = Date.now();
  try {
    const { data, error } = await supabase.from('factories').select('id').limit(1);
    if (!error) {
      isSupabaseHealthy = true;
      hasCheckedTables = true;
      console.log('✅ [Supabase] Connected successfully. Tables detected in remote database.');
      return true;
    }
    hasCheckedTables = true;
    isSupabaseHealthy = false;
    return false;
  } catch (err) {
    hasCheckedTables = true;
    isSupabaseHealthy = false;
    return false;
  }
}

export async function isTableReady(): Promise<boolean> {
  if (isSupabaseHealthy) return true;
  const now = Date.now();
  if (hasCheckedTables && now - lastCheckTime < CHECK_INTERVAL_MS) {
    return isSupabaseHealthy;
  }
  return await testSupabaseConnection();
}

// Data adapter with automatic fallback to in-memory store if tables are not yet created
export const supabaseAdapter = {
  // Factories
  async getFactories(): Promise<Factory[]> {
    if (await isTableReady()) {
      try {
        const { data, error } = await supabase.from('factories').select('*').order('id');
        if (!error && data && data.length > 0) {
          return data as Factory[];
        }
      } catch {
        // Fallback
      }
    }
    return db.factories;
  },

  async getFactoryById(factoryId: string): Promise<Factory | null> {
    if (await isTableReady()) {
      try {
        const { data, error } = await supabase.from('factories').select('*').eq('id', factoryId).single();
        if (!error && data) {
          return data as Factory;
        }
      } catch {
        // Fallback
      }
    }
    return db.factories.find(f => f.id === factoryId) || null;
  },

  // Machines
  async getMachines(factoryId?: string): Promise<Machine[]> {
    if (await isTableReady()) {
      try {
        let query = supabase.from('machines').select('*');
        if (factoryId) {
          query = query.eq('factory_id', factoryId);
        }
        const { data, error } = await query;
        if (!error && data && data.length > 0) {
          return data as Machine[];
        }
      } catch {
        // Fallback
      }
    }
    return factoryId ? db.getMachinesForFactory(factoryId) : db.machines;
  },

  async getMachineById(id: string): Promise<Machine | null> {
    if (await isTableReady()) {
      try {
        const { data, error } = await supabase
          .from('machines')
          .select('*')
          .or(`id.eq.${id},machine_id.eq.${id}`)
          .single();
        if (!error && data) {
          return data as Machine;
        }
      } catch {
        // Fallback
      }
    }
    return db.machines.find(m => m.id === id || m.machine_id === id) || null;
  },

  // Production Records
  async getProduction(factoryId?: string): Promise<ProductionRecord[]> {
    if (await isTableReady()) {
      try {
        let query = supabase.from('production_records').select('*');
        if (factoryId) {
          query = query.eq('factory_id', factoryId);
        }
        const { data, error } = await query;
        if (!error && data && data.length > 0) {
          return data as ProductionRecord[];
        }
      } catch {
        // Fallback
      }
    }
    return db.getProductionForFactory(factoryId || 'FAC-001');
  },

  // Maintenance Records
  async getMaintenance(factoryId?: string): Promise<MaintenanceRecord[]> {
    if (await isTableReady()) {
      try {
        let query = supabase.from('maintenance_records').select('*');
        if (factoryId) {
          query = query.eq('factory_id', factoryId);
        }
        const { data, error } = await query;
        if (!error && data && data.length > 0) {
          return data as MaintenanceRecord[];
        }
      } catch {
        // Fallback
      }
    }
    return db.getMaintenanceForFactory(factoryId || 'FAC-001');
  },

  // Incidents
  async getIncidents(factoryId?: string): Promise<Incident[]> {
    if (await isTableReady()) {
      try {
        let query = supabase.from('incidents').select('*').order('reported_at', { ascending: false });
        if (factoryId) {
          query = query.eq('factory_id', factoryId);
        }
        const { data, error } = await query;
        if (!error && data && data.length > 0) {
          return data as Incident[];
        }
      } catch {
        // Fallback
      }
    }
    return db.getIncidentsForFactory(factoryId || 'FAC-001');
  },



  async createIncident(incident: Incident): Promise<Incident> {
    // 1. Write to in-memory store immediately
    db.incidents.unshift(incident);

    // 2. Write to Supabase if available
    try {
      const { data, error } = await supabase.from('incidents').insert(incident).select().single();
      if (!error && data) {
        return data as Incident;
      }
    } catch (err) {
      console.warn('[Supabase] Incident saved to memory, pending Supabase sync:', err);
    }
    return incident;
  },

  // Work Orders
  async getWorkOrders(factoryId?: string): Promise<WorkOrder[]> {
    if (await isTableReady()) {
      try {
        let query = supabase.from('work_orders').select('*').order('created_at', { ascending: false });
        if (factoryId) {
          query = query.eq('factory_id', factoryId);
        }
        const { data, error } = await query;
        if (!error && data && data.length > 0) {
          return data as WorkOrder[];
        }
      } catch {
        // Fallback
      }
    }
    return db.getWorkOrdersForFactory(factoryId || 'FAC-001');
  },

  async createWorkOrder(workOrder: WorkOrder): Promise<WorkOrder> {
    db.workOrders.unshift(workOrder);

    try {
      const { data, error } = await supabase.from('work_orders').insert(workOrder).select().single();
      if (!error && data) {
        return data as WorkOrder;
      }
    } catch (err) {
      console.warn('[Supabase] Work order saved to memory, pending Supabase sync:', err);
    }
    return workOrder;
  },

  async updateWorkOrder(id: string, updates: Partial<WorkOrder>): Promise<WorkOrder | null> {
    const existing = db.workOrders.find(w => w.id === id || w.work_order_id === id);
    if (existing) {
      Object.assign(existing, updates);
    }

    try {
      const { data, error } = await supabase
        .from('work_orders')
        .update(updates)
        .or(`id.eq.${id},work_order_id.eq.${id}`)
        .select()
        .single();
      if (!error && data) {
        return data as WorkOrder;
      }
    } catch (err) {
      console.warn('[Supabase] Work order updated in memory, pending Supabase sync:', err);
    }
    return existing || null;
  },

  // SOPs
  async getSOPs(factoryId?: string): Promise<SOP[]> {
    if (await isTableReady()) {
      try {
        let query = supabase.from('sops').select('*');
        if (factoryId) {
          query = query.eq('factory_id', factoryId);
        }
        const { data, error } = await query;
        if (!error && data && data.length > 0) {
          return data as SOP[];
        }
      } catch {
        // Fallback
      }
    }
    return db.getSOPsForFactory(factoryId || 'FAC-001');
  },

  // Data Quality
  async getDataQuality(factoryId?: string): Promise<DataQualityMetric[]> {
    if (await isTableReady()) {
      try {
        let query = supabase.from('data_quality_metrics').select('*');
        if (factoryId) {
          query = query.eq('factory_id', factoryId);
        }
        const { data, error } = await query;
        if (!error && data && data.length > 0) {
          return data as DataQualityMetric[];
        }
      } catch {
        // Fallback
      }
    }
    return db.getDataQualityForFactory(factoryId || 'FAC-001');
  },

  // Users
  async getUsers(factoryId?: string | null): Promise<User[]> {
    if (await isTableReady()) {
      try {
        let query = supabase.from('users').select('id, name, email, role, factory_id, status, created_at');
        if (factoryId) {
          query = query.eq('factory_id', factoryId);
        }
        const { data, error } = await query;
        if (!error && data && data.length > 0) {
          return data as User[];
        }
      } catch {
        // Fallback
      }
    }
    const filtered = factoryId ? db.users.filter(u => u.factory_id === factoryId) : db.users;
    return filtered.map(u => ({
      id: u.id,
      name: u.name,
      email: u.email,
      role: u.role,
      factory_id: u.factory_id,
      factory_name: u.factory_name,
      status: u.status,
      created_at: u.created_at
    }));
  },

  // Dynamic KPI Calculation (Supabase-aware with dynamic calculations)
  async calculateFactoryKPIs(factoryId: string): Promise<FactoryKPIs> {
    try {
      const [factories, machines, incidents, workOrders, maintenance, production] = await Promise.all([
        this.getFactories(),
        this.getMachines(factoryId),
        this.getIncidents(factoryId),
        this.getWorkOrders(factoryId),
        this.getMaintenance(factoryId),
        this.getProduction(factoryId)
      ]);

      const factory = factories.find(f => f.id === factoryId);
      const totalMachines = machines.length;
      const runningMachines = machines.filter(m => m.status === 'running').length;
      const warningMachines = machines.filter(m => m.status === 'warning').length;
      const maintenanceMachines = machines.filter(m => m.status === 'maintenance').length;
      const offlineMachines = machines.filter(m => m.status === 'offline').length;

      const activeMachinesWithOee = machines.filter(m => m.status !== 'offline' && m.status !== 'maintenance');
      const avgOee = activeMachinesWithOee.length > 0
        ? activeMachinesWithOee.reduce((sum, m) => sum + m.oee, 0) / activeMachinesWithOee.length
        : 85.0;

      const avgHealth = machines.length > 0
        ? machines.reduce((sum, m) => sum + m.health_score, 0) / machines.length
        : 80.0;

      const totalProd = production.reduce((sum, p) => sum + p.actual_units, 0);
      const targetProd = production.reduce((sum, p) => sum + p.target_units, 0);
      const defectiveProd = production.reduce((sum, p) => sum + p.defective_units, 0);
      const defectRate = totalProd > 0 ? (defectiveProd / totalProd) * 100 : 1.2;

      const downtimeHours = maintenance.reduce((sum, m) => sum + m.downtime_hours, 0);
      const activeIncidents = incidents.filter(i => i.status === 'Open' || i.status === 'Investigating').length;
      const criticalIncidents = incidents.filter(i => (i.status === 'Open' || i.status === 'Investigating') && (i.severity === 'Critical' || i.severity === 'High')).length;
      const openWorkOrders = workOrders.filter(w => w.status === 'Pending' || w.status === 'In Progress').length;
      const pendingMaintenance = maintenance.filter(m => m.status === 'Scheduled' || m.status === 'In Progress').length;

      const availability = Math.min(98.5, Math.max(75, 100 - (maintenanceMachines * 4.5) - (warningMachines * 1.5)));
      const quality = Math.min(99.8, Math.max(90, 100 - defectRate));
      const performance = Math.min(99.0, Math.max(80, (avgOee / (availability * quality / 10000))));

      return {
        factory_id: factoryId,
        factory_name: factory?.name || 'Unknown Factory',
        total_machines: totalMachines,
        running_machines: runningMachines,
        warning_machines: warningMachines,
        maintenance_machines: maintenanceMachines,
        offline_machines: offlineMachines,
        oee: Math.round(avgOee * 10) / 10,
        availability: Math.round(availability * 10) / 10,
        performance: Math.round(performance * 10) / 10,
        quality: Math.round(quality * 10) / 10,
        total_production_units: totalProd > 0 ? totalProd : 28400,
        target_production_units: targetProd > 0 ? targetProd : 30000,
        defective_units: defectiveProd > 0 ? defectiveProd : 290,
        defect_rate_pct: Math.round(defectRate * 100) / 100,
        downtime_hours: Math.round(downtimeHours * 10) / 10,
        active_incidents: activeIncidents,
        critical_incidents: criticalIncidents,
        open_work_orders: openWorkOrders,
        pending_maintenance: pendingMaintenance,
        avg_health_score: Math.round(avgHealth * 10) / 10
      };
    } catch {
      return db.calculateFactoryKPIs(factoryId);
    }
  },

  // Dynamic Super Admin Overview
  async getSuperAdminOverview(): Promise<SuperAdminOverview> {
    try {
      const factories = await this.getFactories();
      const factoriesWithKpis = await Promise.all(
        factories.map(async f => {
          const kpis = await this.calculateFactoryKPIs(f.id);
          return {
            ...f,
            machine_count: kpis.total_machines,
            running_count: kpis.running_machines,
            oee: kpis.oee,
            active_incidents: kpis.active_incidents,
            open_work_orders: kpis.open_work_orders,
            kpis
          };
        })
      );

      const totalMachines = factoriesWithKpis.reduce((acc, f) => acc + f.kpis.total_machines, 0);
      const totalProduction = factoriesWithKpis.reduce((acc, f) => acc + f.kpis.total_production_units, 0);
      const activeIncidents = factoriesWithKpis.reduce((acc, f) => acc + f.kpis.active_incidents, 0);
      const openWorkOrders = factoriesWithKpis.reduce((acc, f) => acc + f.kpis.open_work_orders, 0);
      const overallOee = factoriesWithKpis.length > 0
        ? factoriesWithKpis.reduce((acc, f) => acc + f.kpis.oee, 0) / factoriesWithKpis.length
        : 85;
      const overallHealth = factoriesWithKpis.length > 0
        ? factoriesWithKpis.reduce((acc, f) => acc + f.kpis.avg_health_score, 0) / factoriesWithKpis.length
        : 80;

      const users = await this.getUsers();

      return {
        total_factories: factories.length,
        active_factories: factories.filter(f => f.status === 'Operational').length,
        total_users: users.length,
        total_machines: totalMachines,
        total_production: totalProduction,
        active_incidents: activeIncidents,
        open_work_orders: openWorkOrders,
        overall_oee: Math.round(overallOee * 10) / 10,
        overall_health: Math.round(overallHealth * 10) / 10,
        factories: factoriesWithKpis
      };
    } catch {
      return db.getSuperAdminOverview();
    }
  }
};
