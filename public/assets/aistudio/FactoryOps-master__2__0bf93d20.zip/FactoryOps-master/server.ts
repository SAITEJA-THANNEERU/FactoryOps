import express, { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import path from 'path';
import { fileURLToPath } from 'url';
import { db, verifyPassword } from './server/db.ts';
import { supabaseAdapter, testSupabaseConnection } from './server/supabase.ts';
import type { User, UserRole, Incident, WorkOrder } from './src/types/index.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// CORS Middleware
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, x-factory-id');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
    return;
  }
  next();
});

app.use(express.json());

// Extend express Request interface
interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    name: string;
    role: UserRole;
    factory_id: string | null;
  };
}

// Authentication middleware
function authenticate(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Unauthorized: Missing or invalid authorization token' });
    return;
  }

  const token = authHeader.split(' ')[1];
  const session = db.sessions.get(token);

  if (!session || session.expiresAt < Date.now()) {
    if (session) db.sessions.delete(token);
    res.status(401).json({ error: 'Unauthorized: Session expired or invalid. Please log in again.' });
    return;
  }

  const user = db.users.find(u => u.id === session.userId);
  if (!user || user.status !== 'active') {
    res.status(401).json({ error: 'Unauthorized: User account not found or deactivated' });
    return;
  }

  req.user = {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    factory_id: user.factory_id
  };

  next();
}

// Role authorization middleware
function authorizeRole(...allowedRoles: UserRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized' });
      return;
    }
    if (!allowedRoles.includes(req.user.role)) {
      res.status(403).json({
        error: `Forbidden: Role '${req.user.role}' is not authorized to access this resource`
      });
      return;
    }
    next();
  };
}

// Helper to determine and enforce factory isolation
function getResolvedFactoryId(req: AuthenticatedRequest, requestedFactoryId?: string): string | null {
  if (!req.user) return null;

  // Super Admin can inspect any factory
  if (req.user.role === 'SUPER_ADMIN') {
    return requestedFactoryId || (req.query.factory_id as string) || (req.headers['x-factory-id'] as string) || null;
  }

  // Factory Owner or Manager is strictly locked to their factory
  const userFactoryId = req.user.factory_id;
  if (!userFactoryId) return null;

  // If a specific factory was requested, verify it matches the user's factory
  const targetId = requestedFactoryId || (req.query.factory_id as string) || (req.headers['x-factory-id'] as string);
  if (targetId && targetId !== userFactoryId) {
    return '__FORBIDDEN__';
  }

  return userFactoryId;
}

// ==========================================
// AUTHENTICATION ROUTES
// ==========================================

// Login endpoint
app.post(['/api/auth/login', '/api/auth/login/'], (req: Request, res: Response): void => {
  const { email, username, password } = req.body || {};
  const identifier = (email || username || '').trim().toLowerCase();

  if (!identifier || !password) {
    res.status(400).json({ success: false, error: 'Username/Email and Password are required' });
    return;
  }

  const user = db.users.find(u => {
    const uEmail = u.email.toLowerCase();
    const uName = u.name.toLowerCase();
    const uUsername = uEmail.split('@')[0];
    return (
      uEmail === identifier ||
      uName === identifier ||
      uUsername === identifier ||
      u.id.toLowerCase() === identifier
    );
  });

  if (!user) {
    res.status(401).json({ success: false, error: 'Invalid email/username or password' });
    return;
  }

  const isValid = verifyPassword(password, user.password_hash, user.salt);
  if (!isValid) {
    res.status(401).json({ success: false, error: 'Invalid email/username or password' });
    return;
  }

  // Create session token valid for 24 hours
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = Date.now() + 24 * 60 * 60 * 1000;

  db.sessions.set(token, {
    userId: user.id,
    role: user.role,
    factoryId: user.factory_id,
    expiresAt
  });

  const factory = user.factory_id ? db.factories.find(f => f.id === user.factory_id) : null;

  // Return user without hash or salt
  const safeUser: User = {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    factory_id: user.factory_id,
    factory_name: factory?.name,
    status: user.status,
    created_at: user.created_at
  };

  res.json({
    success: true,
    token,
    user: safeUser,
    factory
  });
});

// Logout endpoint
app.post(['/api/auth/logout', '/api/auth/logout/'], (req: AuthenticatedRequest, res: Response): void => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    db.sessions.delete(token);
  }
  res.json({ success: true, message: 'Successfully logged out' });
});

// Current User Me endpoint
app.get(['/api/auth/me', '/api/auth/me/'], authenticate, (req: AuthenticatedRequest, res: Response): void => {
  const user = db.users.find(u => u.id === req.user!.id);
  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }

  const factory = user.factory_id ? db.factories.find(f => f.id === user.factory_id) : null;
  const safeUser: User = {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    factory_id: user.factory_id,
    factory_name: factory?.name,
    status: user.status,
    created_at: user.created_at
  };

  res.json({
    success: true,
    user: safeUser,
    factory
  });
});

// ==========================================
// SUPER ADMIN ROUTES
// ==========================================

// Super Admin Overview of all 5 factories
app.get('/api/super-admin/overview', authenticate, authorizeRole('SUPER_ADMIN'), async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const overview = await supabaseAdapter.getSuperAdminOverview();
  res.json(overview);
});

// ==========================================
// FACTORIES ROUTES
// ==========================================

// List factories
app.get('/api/factories', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  if (req.user!.role === 'SUPER_ADMIN') {
    // Super Admin gets all factories with their calculated KPIs
    const overview = await supabaseAdapter.getSuperAdminOverview();
    res.json(overview.factories);
    return;
  }

  // Factory Owner or Manager gets ONLY their own factory
  const factories = await supabaseAdapter.getFactories();
  const userFactory = factories.find(f => f.id === req.user!.factory_id);
  if (!userFactory) {
    res.status(404).json({ error: 'Assigned factory not found' });
    return;
  }

  const kpis = await supabaseAdapter.calculateFactoryKPIs(userFactory.id);
  res.json([{
    ...userFactory,
    machine_count: kpis.total_machines,
    running_count: kpis.running_machines,
    oee: kpis.oee,
    active_incidents: kpis.active_incidents,
    open_work_orders: kpis.open_work_orders,
    kpis
  }]);
});

// Get specific factory
app.get('/api/factories/:id', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const factoryId = req.params.id;

  // Strict isolation check
  if (req.user!.role !== 'SUPER_ADMIN' && req.user!.factory_id !== factoryId) {
    res.status(403).json({
      error: `Forbidden: You do not have permission to access factory ${factoryId}`
    });
    return;
  }

  const factory = await supabaseAdapter.getFactoryById(factoryId);
  if (!factory) {
    res.status(404).json({ error: 'Factory not found' });
    return;
  }

  const kpis = await supabaseAdapter.calculateFactoryKPIs(factory.id);
  res.json({
    ...factory,
    machine_count: kpis.total_machines,
    running_count: kpis.running_machines,
    oee: kpis.oee,
    active_incidents: kpis.active_incidents,
    open_work_orders: kpis.open_work_orders,
    kpis
  });
});

// Get factory dynamic KPIs
app.get('/api/factories/:id/stats', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const factoryId = req.params.id;

  // Strict isolation check
  if (req.user!.role !== 'SUPER_ADMIN' && req.user!.factory_id !== factoryId) {
    res.status(403).json({
      error: `Forbidden: Access to factory ${factoryId} data is denied`
    });
    return;
  }

  const kpis = await supabaseAdapter.calculateFactoryKPIs(factoryId);
  res.json(kpis);
});

// ==========================================
// OPERATIONAL ROUTES (MACHINES, PRODUCTION, ETC.)
// ==========================================

// Machines
app.get('/api/machines', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const resolvedFactoryId = getResolvedFactoryId(req);

  if (resolvedFactoryId === '__FORBIDDEN__') {
    res.status(403).json({ error: 'Forbidden: Cannot access machines for another factory' });
    return;
  }

  if (!resolvedFactoryId && req.user!.role === 'SUPER_ADMIN') {
    // Super admin without factory query gets all machines
    const machines = await supabaseAdapter.getMachines();
    res.json(machines);
    return;
  }

  if (!resolvedFactoryId) {
    res.status(400).json({ error: 'Factory ID is required' });
    return;
  }

  const machines = await supabaseAdapter.getMachines(resolvedFactoryId);
  res.json(machines);
});

app.get('/api/machines/:id', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const machine = await supabaseAdapter.getMachineById(req.params.id);

  if (!machine) {
    res.status(404).json({ error: 'Machine not found' });
    return;
  }

  // Strict cross-factory isolation check
  if (req.user!.role !== 'SUPER_ADMIN' && req.user!.factory_id !== machine.factory_id) {
    res.status(403).json({
      error: `Forbidden: Machine ${machine.machine_id} belongs to a different factory`
    });
    return;
  }

  res.json(machine);
});

// Production records
app.get('/api/production', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const resolvedFactoryId = getResolvedFactoryId(req);

  if (resolvedFactoryId === '__FORBIDDEN__') {
    res.status(403).json({ error: 'Forbidden: Cannot access production records for another factory' });
    return;
  }

  const factoryId = resolvedFactoryId || 'FAC-001';
  const records = await supabaseAdapter.getProduction(factoryId);
  res.json(records);
});

// Maintenance records
app.get('/api/maintenance', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const resolvedFactoryId = getResolvedFactoryId(req);

  if (resolvedFactoryId === '__FORBIDDEN__') {
    res.status(403).json({ error: 'Forbidden: Cannot access maintenance records for another factory' });
    return;
  }

  const factoryId = resolvedFactoryId || 'FAC-001';
  const records = await supabaseAdapter.getMaintenance(factoryId);
  res.json(records);
});

// Incidents
app.get('/api/incidents', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const resolvedFactoryId = getResolvedFactoryId(req);

  if (resolvedFactoryId === '__FORBIDDEN__') {
    res.status(403).json({ error: 'Forbidden: Cannot access incidents for another factory' });
    return;
  }

  const factoryId = resolvedFactoryId || 'FAC-001';
  const incidents = await supabaseAdapter.getIncidents(factoryId);
  res.json(incidents);
});

app.post('/api/incidents', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const { machine_id, title, description, severity } = req.body;
  const resolvedFactoryId = getResolvedFactoryId(req);

  if (resolvedFactoryId === '__FORBIDDEN__' || !resolvedFactoryId) {
    res.status(403).json({ error: 'Forbidden: Cannot report incidents for another factory' });
    return;
  }

  // Validate machine belongs to authorized factory
  const machines = await supabaseAdapter.getMachines(resolvedFactoryId);
  const machine = machines.find(m => (m.machine_id === machine_id || m.id === machine_id));
  if (!machine) {
    res.status(400).json({ error: `Machine ${machine_id} does not exist in this factory` });
    return;
  }

  const newIncident: Incident = {
    id: `INC-${Date.now()}`,
    incident_id: `INC-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    factory_id: resolvedFactoryId,
    machine_id: machine.machine_id,
    title: title || 'Operational Anomaly',
    description: description || '',
    severity: severity || 'Medium',
    status: 'Open',
    reported_by: req.user!.name,
    reported_at: new Date().toISOString()
  };

  const created = await supabaseAdapter.createIncident(newIncident);
  res.status(201).json(created);
});

// Work Orders
app.get('/api/work-orders', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const resolvedFactoryId = getResolvedFactoryId(req);

  if (resolvedFactoryId === '__FORBIDDEN__') {
    res.status(403).json({ error: 'Forbidden: Cannot access work orders for another factory' });
    return;
  }

  const factoryId = resolvedFactoryId || 'FAC-001';
  const workOrders = await supabaseAdapter.getWorkOrders(factoryId);
  res.json(workOrders);
});

app.post('/api/work-orders', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const { machine_id, title, priority, assigned_to, due_date, estimated_hours, parts_required } = req.body;
  const resolvedFactoryId = getResolvedFactoryId(req);

  if (resolvedFactoryId === '__FORBIDDEN__' || !resolvedFactoryId) {
    res.status(403).json({ error: 'Forbidden: Cannot create work orders for another factory' });
    return;
  }

  // Validate machine belongs to factory
  const machines = await supabaseAdapter.getMachines(resolvedFactoryId);
  const machine = machines.find(m => (m.machine_id === machine_id || m.id === machine_id));
  if (!machine) {
    res.status(400).json({ error: `Machine ${machine_id} does not exist in this factory` });
    return;
  }

  const newWorkOrder: WorkOrder = {
    id: `WO-${Date.now()}`,
    work_order_id: `WO-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    factory_id: resolvedFactoryId,
    machine_id: machine.machine_id,
    title: title || 'Maintenance Task',
    priority: priority || 'Medium',
    status: 'Pending',
    assigned_to: assigned_to || 'Assigned Technician',
    due_date: due_date || new Date(Date.now() + 3 * 86400000).toISOString().split('T')[0],
    created_at: new Date().toISOString(),
    estimated_hours: Number(estimated_hours) || 2,
    parts_required: parts_required || ''
  };

  const created = await supabaseAdapter.createWorkOrder(newWorkOrder);
  res.status(201).json(created);
});

app.patch('/api/work-orders/:id', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const factoryId = req.user!.role === 'SUPER_ADMIN' ? undefined : (req.user!.factory_id || undefined);
  const workOrders = await supabaseAdapter.getWorkOrders(factoryId);
  const workOrder = workOrders.find(w => w.id === req.params.id || w.work_order_id === req.params.id);

  if (!workOrder) {
    res.status(404).json({ error: 'Work order not found' });
    return;
  }

  if (req.user!.role !== 'SUPER_ADMIN' && req.user!.factory_id !== workOrder.factory_id) {
    res.status(403).json({ error: 'Forbidden: Work order belongs to another factory' });
    return;
  }

  const { status, assigned_to, actual_hours } = req.body;
  const updates: Partial<WorkOrder> = {};
  if (status) updates.status = status;
  if (assigned_to) updates.assigned_to = assigned_to;
  if (actual_hours !== undefined) updates.actual_hours = Number(actual_hours);
  if (status === 'Completed' && !workOrder.completed_at) {
    updates.completed_at = new Date().toISOString();
  }

  const updated = await supabaseAdapter.updateWorkOrder(req.params.id, updates);
  res.json(updated || workOrder);
});

// SOPs
app.get('/api/sops', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const resolvedFactoryId = getResolvedFactoryId(req);

  if (resolvedFactoryId === '__FORBIDDEN__') {
    res.status(403).json({ error: 'Forbidden: Cannot access SOPs for another factory' });
    return;
  }

  const factoryId = resolvedFactoryId || 'FAC-001';
  const sops = await supabaseAdapter.getSOPs(factoryId);
  res.json(sops);
});

// Data Quality
app.get('/api/data-quality', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const resolvedFactoryId = getResolvedFactoryId(req);

  if (resolvedFactoryId === '__FORBIDDEN__') {
    res.status(403).json({ error: 'Forbidden: Cannot access data quality for another factory' });
    return;
  }

  const factoryId = resolvedFactoryId || 'FAC-001';
  const dq = await supabaseAdapter.getDataQuality(factoryId);
  res.json(dq);
});

// Users Management
app.get('/api/users', authenticate, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const factoryId = req.user!.role === 'SUPER_ADMIN' ? null : req.user!.factory_id;
  const users = await supabaseAdapter.getUsers(factoryId);
  res.json(users);
});

// API 404 Fallback - Ensures unhandled API routes return JSON and NEVER fall through to HTML/Vite
app.all('/api/*', (req: Request, res: Response): void => {
  res.status(404).json({ error: `API route not found: ${req.method} ${req.path}` });
});

// Global API Error Handler
app.use((err: any, req: Request, res: Response, next: NextFunction): void => {
  if (req.path.startsWith('/api')) {
    console.error('[API Error]', err);
    res.status(err.status || 500).json({ error: err.message || 'Internal Server Error' });
    return;
  }
  next(err);
});

// ==========================================
// VITE DEV SERVER / STATIC ASSETS
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', async () => {
    console.log(`[FactoryOps] Enterprise Server running at http://0.0.0.0:${PORT}`);
    await testSupabaseConnection();
  });
}

startServer();
